function ALL_VAR = concatField(x1, x2, x3, lenD, lenM, lenJ, VAR_D, VAR_M, VAR_J, VAR_S)

ALL_VAR = zeros(x1,x2,x3);
dummy = zeros(x1,x2,1);

if size(VAR_D,3) == 1; dummy(:,:,1) = VAR_D; VAR_D = dummy; end
if size(VAR_M,3) == 1; dummy(:,:,1) = VAR_M; VAR_M = dummy; end
if size(VAR_J,3) == 1; dummy(:,:,1) = VAR_J; VAR_J = dummy; end
if size(VAR_S,3) == 1; dummy(:,:,1) = VAR_S; VAR_S = dummy; end


ALL_VAR(:,:,1:lenD) = VAR_D;
ALL_VAR(:,:,lenD+1:lenD+lenM) = VAR_M;
ALL_VAR(:,:,lenD+lenM+1:lenD+lenM+lenJ) = VAR_J;
ALL_VAR(:,:,(lenD+lenM+lenJ+1):end) = VAR_S;
% 
% if lenJ ==1
%     dummy(:,:,1) = VAR_J;
%     ALL_VAR(:,:,lenD+lenM+1) = dummy;
% else
%     ALL_VAR(:,:,lenD+lenM+1:lenD+lenM+lenJ) = VAR_J;
% end

% if size(VAR_S,1) == 1
%     dummy(:,:,1) = VAR_S;
%     ALL_VAR(:,:,lenD+lenM+lenJ+1) = dummy;
% else
%     ALL_VAR(:,:,(lenD+lenM+lenJ+1):end) = VAR_S;
% end


