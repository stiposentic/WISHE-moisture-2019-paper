function [varALL, varDJF, varMAM, varJJA, varSON] = varMonths(var,dateVector);

dayDJF = dateVector(:,2)==12 | dateVector(:,2)==1  | dateVector(:,2)==2;
dayMAM = dateVector(:,2)==3  | dateVector(:,2)==4  | dateVector(:,2)==5;
dayJJA = dateVector(:,2)==6  | dateVector(:,2)==7  | dateVector(:,2)==8;
daySON = dateVector(:,2)==9  | dateVector(:,2)==10 | dateVector(:,2)==11;

varDJF = var(dayDJF,:);
varMAM = var(dayMAM,:);
varJJA = var(dayJJA,:);
varSON = var(daySON,:);
varALL = var;



