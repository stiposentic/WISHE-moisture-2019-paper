%-20 20 
%-15 15
%-10 10
%-5 5
%0 5
%5 0

%OLR filtOLR

% ERAI 
% U1000 U850 U200 U10 SF II
% 1991 2010
% 2000 2016

% FNL 
% U10 SF II
% 1991 2010
% 2000 2016

% MERRA2
% U10 SF II
% 1991 2010
% 2000 2016



% MODELS:
% CNRM good MJO model
% NAVGEM bad MJO model
% U1000 SF II
% 1991 2010

RELOAD = 1;

if RELOAD

clear all;
close all;
%pkg load netcdf



%DATA = 'CNRM'; FNL=0; MERRA=0; MODEL='CNRM_'; MODELS =1;
%multiplierOLR = 1; multiplierVARS = 1; 
%Ulabel = 'U1000'; UlabelVar = 'U1000'; multiplierU = 1;
%year1 = '1991'; year1n = 1991;
%year2 = '2010'; year2n = 2010;

%DATA = 'NAVGEM'; FNL=0; MERRA=0; MODEL='NAVGEM_'; MODELS =1;
%multiplierOLR = 1; multiplierVARS = 1;
%Ulabel = 'U1000'; UlabelVar = 'U1000'; multiplierU = 1;
%year1 = '1991'; year1n = 1991;
%year2 = '2010'; year2n = 2010;


%DATA = 'ERAI'; FNL=0; MERRA=0; MODEL=''; MODELS=0; filteredOLRlabel = 'k1_5_';
%multiplierOLR = 1; multiplierVARS = 2; 
%Ulabel = 'U10'; UlabelVar = 'u10'; multiplierU = 2;
%%Ulabel = 'U200'; UlabelVar = 'U200'; multiplierU = 4;
%year1 = '1986'; year1n = 1986;
%year2 = '2018'; year2n = 2018;

DATA = 'FNL'; FNL=1; MERRA=0; MODEL=''; MODELS=0; filteredOLRlabel = 'k1_5_';
multiplierOLR = 1; multiplierVARS = 4;
Ulabel = 'U10'; UlabelVar = 'U10'; multiplierU = 4;
year1 = '2000'; year1n = 2000;
year2 = '2016'; year2n = 2016;

%DATA = 'MERRA2'; FNL=0; MERRA = 1; MODEL=''; MODELS=0;
%multiplierOLR = 1; multiplierVARS = 4;
%Ulabel = 'U10'; UlabelVar = 'U10'; multiplierU = 4;
%year1 = '2000'; year1n = 2000;
%year2 = '2016'; year2n = 2016;




%FILESPATH = '/data.qt3/ssentic/EASTERLY_DATA/';
FILESPATH = '';
EXCLUDE = 0; EXCLUDE_WEAKER = 0; OLRcutoff = 0; % ALL data, no Exclusions
EXCLUDE = 1; EXCLUDE_WEAKER = 1; OLRcutoff = -11; % exclude weaker MJOs
%EXCLUDE = 1; EXCLUDE_WEAKER = 0; OLRcutoff = -13; % exclude stronger MJOs
EXTRA_EXCLUDE_LABEL = [ 'EX' num2str(EXCLUDE) '.' num2str(EXCLUDE_WEAKER) '.' num2str(abs(OLRcutoff)) ];
% include only MJOs with maxima between LON1 and LON2
LON1 = 50; LON2 = 200;
%LON1 = 50; LON2 = 100;
%LON1 = 100; LON2 = 150;
%LON1 = 150; LON2 = 200;
%LON1 = 0; LON2 = 360;
%LON1 = 30; LON2 = 250;
%LON1 = 30; LON2 = 140;
%LON1 = 140; LON2 = 250;
LON_EXCLUDE_LABEL = [ 'LON' num2str(LON1,'%03i') '_' num2str(LON2,'%03i') ];
% choice: 5 10 15 20 symetric around the equator, or -5 to 0 and 0 to 5
lat1 = '-10';
lat2 = '10';
%lat1 = '0';
%lat2 = '5';


range = datenum(str2num(year2), 12, 31) - datenum(str2num(year1)-1, 12, 31)-1;
dateVector = dateVectorFunction(str2num(year1),str2num(year2),MODELS);

%	OLR, time in days from start year
OLR     = ncread([FILESPATH 'OLR_' MODEL year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'olr');
OLR(OLR>1000) = NaN; % exclude missing data ( a few periods are missing
OLRlon  = ncread([FILESPATH 'OLR_' MODEL year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');      % from 0.5 deg to 359.5 deg
OLRtime = ncread([FILESPATH 'OLR_' MODEL year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');     % counting from day 1 of start year
OLRfilt = ncread([FILESPATH 'FiltOLR_MJO_' filteredOLRlabel MODEL year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'filtdata');
filteredOLRlabel = '';
%OLRfilt = [OLRfilt; OLRfilt(end,:)];
%OLRfiltROSSBY = ncread([FILESPATH 'FiltOLR_ROSSBY_' filteredOLRlabel MODEL year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'filtdata');
% get sf, ii
II     = ncread([FILESPATH DATA '_VARS_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'sf'); % !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! sf instead of II!!!!!
IItime = ncread([FILESPATH DATA '_VARS_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');
IIlon  = ncread([FILESPATH DATA '_VARS_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');

EXTRALABEL = '';
SF     = ncread([FILESPATH DATA '_VARS_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'sf');
SFtime = ncread([FILESPATH DATA '_VARS_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');
SFlon  = ncread([FILESPATH DATA '_VARS_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');

%vDmrDlat = ncread([FILESPATH DATA '_MR850_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'dmrdt')';
%vDmrDlatlon = ncread([FILESPATH DATA '_MR850_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');
%vDmrDlattime = ncread([FILESPATH DATA '_MR850_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');

vDmrDlat = ncread([FILESPATH DATA '_MR100850_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'dmrdt')';
vDmrDlatlon = ncread([FILESPATH DATA '_MR100850_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');
vDmrDlattime = ncread([FILESPATH DATA '_MR100850_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');

uDmrDlon = ncread([FILESPATH DATA '_MR850_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'dmrdt')';
uDmrDlonlon = ncread([FILESPATH DATA '_MR850_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');
uDmrDlontime = ncread([FILESPATH DATA '_MR850_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');

SF = ncread([FILESPATH DATA '_MR100_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'mr')';
SFlon = ncread([FILESPATH DATA '_MR100_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');
SFtime = ncread([FILESPATH DATA '_MR100_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');





%EXTRALABEL = 'mr_BL1km_latAve10';
%SF     = ncread('ERAI_Q1km_1986_2018.nc','mr1km10')';
%SFtime = ncread('ERAI_Q1km_1986_2018.nc','time');
%SFlon  = ncread('ERAI_Q1km_1986_2018.nc','lon');

%EXTRALABEL = 'sf_latAve10';
%SF     = ncread('ERAI_Qall_1986_2018.nc','sf10')';
%SFtime = ncread('ERAI_Qall_1986_2018.nc','time');
%SFlon  = ncread('ERAI_Qall_1986_2018.nc','lon');



% get zonal Wind
U     = ncread([FILESPATH DATA '_' Ulabel '_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],UlabelVar);
Ulon  = ncread([FILESPATH DATA '_' Ulabel '_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');
Utime = ncread([FILESPATH DATA '_' Ulabel '_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% get surface fluxes
RFLUX = ncread([FILESPATH DATA '_FLUXES_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'rflux');
HFLUX = ncread([FILESPATH DATA '_FLUXES_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'hflux');
FLUXlon = ncread([FILESPATH DATA '_FLUXES_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');
FLUXtime = ncread([FILESPATH DATA '_FLUXES_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');
multiplierFLUX = 4;

% get surface fluxes U only used in Surface flux calculation
RFLUX1 = ncread('FLUXUnoly_2000_2018_10_10.nc','rflux')';
HFLUX1 = ncread('FLUXUnoly_2000_2018_10_10.nc','hflux')';
FLUXlon1 = ncread('FLUXUnoly_2000_2018_10_10.nc','lon');
FLUXtime1 = ncread('FLUXUnoly_2000_2018_10_10.nc','time');
% get surface fluxes for v only
%RFLUX2 = ncread('FLUXVUonly_2000_2018_10_10.nc','rflux')';
HFLUX2 = ncread('FLUXVUonly_2000_2018_10_10.nc','hflux')';

RFLUX1 = RFLUX1(1:end-2,:);
RFLUX2 = RFLUX - RFLUX1;

% U plus V only
RFLUX12 = RFLUX1 + RFLUX2;
HFLUX12 = HFLUX1 + HFLUX2;

multiplierFLUX_OAFLUX = 1;
RFLUX_OAFLUX = ncread([FILESPATH 'lh_oaflux_' year1 '_' year2 '.nc'],'lhtfl')';
HFLUX_OAFLUX = ncread([FILESPATH 'sh_oaflux_' year1 '_' year2 '.nc'],'shtfl')';
FLUXlon_OAFLUX = ncread([FILESPATH 'lh_oaflux_' year1 '_' year2 '.nc'],'lon');
FLUXtime_OAFLUX = ncread([FILESPATH 'lh_oaflux_' year1 '_' year2 '.nc'],'time');




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%horiz and vert fluxes
convert = (-100/9.81)*86400 *3.45/100;
% FLUXH = convert * ncread([FILESPATH DATA '_FLUXVH_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'horizAdv')';
% FLUXV = (convert/100) * ncread([FILESPATH DATA '_FLUXVH_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'vertAdv')';
% uDmrDlon = convert * ncread([FILESPATH DATA '_FLUXVH_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'uDmrDlon')';
% vDmrDlat = convert * ncread([FILESPATH DATA '_FLUXVH_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'vDmrDlat')';
% FLUXVHlon = ncread([FILESPATH DATA '_FLUXVH_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');
% FLUXVHtime = ncread([FILESPATH DATA '_FLUXVH_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');

%BUOYlh     = ncread('TOATRION1986_2018.nc','lh');
%BUOYlon    = ncread('TOATRION1986_2018.nc','lon')';
%BUOYtime   = ncread('TOATRION1986_2018.nc','time')';
%BUOYlh(BUOYlh > 100000) = NaN;
%BUOYlh(1:4000,:) = NaN;

FLUXH = SF;
FLUXV = SF;
%uDmrDlon = SF;
%vDmrDlat = SF;
FLUXVHlon = SFlon;
FLUXVHtime = SFtime;

vDmrDlat(vDmrDlat > 100000) = NaN;
RFLUX(RFLUX > 100000) = NaN;
HFLUX(HFLUX > 100000) = NaN;
RFLUX1(RFLUX1 > 100000) = NaN;
HFLUX1(HFLUX1 > 100000) = NaN;
RFLUX2(RFLUX2 > 100000) = NaN;
HFLUX2(HFLUX2 > 100000) = NaN;
RFLUX_OAFLUX(RFLUX_OAFLUX > 100000) = NaN;
HFLUX_OAFLUX(HFLUX_OAFLUX > 100000) = NaN;

[U, Utime, multiplierU] = averageDaily(U,Utime,multiplierU,'U');
[SF, SFtime, multiplierSF]   = averageDaily(SF,SFtime,multiplierVARS, 'SF');
[II, IItime, multiplierVARS] = averageDaily(II,IItime,multiplierVARS, 'II');

[RFLUX, FLUXtimeTMP, multiplierTMP] = averageDaily(RFLUX,FLUXtime,multiplierFLUX, 'RFLUX');
[HFLUX, FLUXtime, multiplierTMP] = averageDaily(HFLUX,FLUXtime,multiplierFLUX, 'HFLUX');

[RFLUX1, FLUXtimeTMP, multiplierTMP] = averageDaily(RFLUX1,FLUXtime1,multiplierFLUX, 'RFLUX1');
[HFLUX1, FLUXtimeTMP, ~] = averageDaily(HFLUX1,FLUXtime1,multiplierFLUX, 'HFLUX1');
[RFLUX2, FLUXtimeTMP, multiplierTMP] = averageDaily(RFLUX2,FLUXtime1,multiplierFLUX, 'RFLUX2');
[HFLUX2, FLUXtimeTMP, multiplierTMP] = averageDaily(HFLUX2,FLUXtime1,multiplierFLUX, 'HFLUX2');
[RFLUX12, FLUXtimeTMP, multiplierTMP] = averageDaily(RFLUX12,FLUXtime1,multiplierFLUX, 'RFLUX12');
[HFLUX12, FLUXtime1, multiplierFLUX] = averageDaily(HFLUX12,FLUXtime1,multiplierFLUX, 'HFLUX12');

[vDmrDlat, vDmrDlattime, multiplierTMP] = averageDaily(vDmrDlat, vDmrDlattime , 4, 'dmrdt100');
[uDmrDlon, uDmrDlontime, multiplierTMP] = averageDaily(uDmrDlon, uDmrDlontime , 4, 'dmrdt850');
SMOOTHWINDOW = 1;
vDmrDlat = smooth2a(double(vDmrDlat),SMOOTHWINDOW*multiplierVARS*2,3);
uDmrDlon = smooth2a(double(uDmrDlon),SMOOTHWINDOW*multiplierVARS*2,3);

%filter the U field with a Lanczos low pass filter
%U                           6210x360
U_filt = U;

dt = 1; % period, 1 day
Nf =1/(2*dt); % Nyquist Frequency
cf = Nf/2; % cut-off frequency
cf = 0.016; % 60 day period cutoff
% Default: half Nyquist(sample_size/2)
n_coef = 151; % number of coefficients
% OUTPUT
%lanc_freq: frequency
%[lanc_fdata,lanc_coef,lanc_window,lanc_fft,lanc_freq] = ...
%lanczosfilter(adams_conc,dt,cf,'100','low');
for i =1:360
%i
  Utmp = U(:,i);
  Y = lanczosfilter(Utmp,dt,cf,[],'low');
  U_filt(:,i) = Y;
end
%figure('visible','off')
%plot(U(:,275),'k');hold on;
%plot(U_filt(:,275),'r')
%xlim([0 300])
%print('filteredU.png','-dpng')
%stop


%if FNL
if 0
  U = [U; U(end,:); U(end,:) ];
  Utime = [Utime; Utime(end)+Utime(end)-Utime(end-1); Utime(end)+2*(Utime(end)-Utime(end-1)) ];
  U = U(1:2:end,:);
  Utime = Utime(1:2:end);
  multiplierU = 2;
  vDmrDlat = vDmrDlat(1:2:end,:);
  vDmrDlattime = vDmrDlattime(1:2:end,:);
  SF = SF(1:2:end,:);
  SFtime = SFtime(1:2:end);
  II = II(1:2:end,:);
  IItime = IItime(1:2:end);
  HFLUX = [HFLUX(1:2:end,:); HFLUX(end,:)];
  RFLUX = [RFLUX(1:2:end,:); RFLUX(end,:)];
  FLUXtime = [FLUXtime(1:2:end); FLUXtime(end)+FLUXtime(end)-FLUXtime(end-1)];
  %HFLUX = [HFLUX(1:2:end,:)];
  %RFLUX = [RFLUX(1:2:end,:)];
  %FLUXtime = [FLUXtime(1:2:end)];
  HFLUX1 = [HFLUX1(1:2:end,:); HFLUX1(end,:)];
  RFLUX1 = [RFLUX1(1:2:end,:); RFLUX1(end,:)];
  FLUXtime1 = [FLUXtime1(1:2:end); FLUXtime1(end)+FLUXtime1(end)-FLUXtime1(end-1)];
  HFLUX2 = [HFLUX2(1:2:end,:); HFLUX2(end,:)];
  RFLUX2 = [RFLUX2(1:2:end,:); RFLUX2(end,:)];
  HFLUX12 = [HFLUX12(1:2:end,:); HFLUX12(end,:)];
  RFLUX12 = [RFLUX12(1:2:end,:); RFLUX12(end,:)];
    multiplierFLUX = 2;
  multiplierVARS = 2;
end

%save('FNL_VARS_2000_2016_-10_10.mat','SF','SFtime','SFlon')
%save('FNL_U10_2000_2016_-10_10.mat','U','Utime','Ulon')
%stop

if MERRA
  U = U(1:6:end,:);
  Utime = Utime(1:6:end);
  U = [U; U(end,:); U(end,:); U(end,:); U(end,:) ];
  Utime = [Utime; Utime(end)+Utime(end)-Utime(end-1); Utime(end)+2*(Utime(end)-Utime(end-1)); ...
           Utime(end)+3*(Utime(end)-Utime(end-1)); Utime(end)+4*(Utime(end)-Utime(end-1)) ];
  Utime = Utime - 3287.0;
end

SMOOTHVARIABLES = 1; SMOOTHWINDOW = 2;
%if SMOOTHVARIABLES
if 0
  OLR   = smooth2a(double(OLR),SMOOTHWINDOW*multiplierOLR ,2); % last number decides that the smoothing will be over 5 degrees
  SF    = smooth2a(double(SF ),SMOOTHWINDOW*multiplierVARS,3);
  vDmrDlat = smooth2a(double(vDmrDlat),SMOOTHWINDOW*multiplierVARS*2,3);
  II    = smooth2a(double(II ),SMOOTHWINDOW*multiplierVARS,3);
  HFLUX = smooth2a(double(HFLUX),SMOOTHWINDOW*multiplierFLUX,2);
  RFLUX = smooth2a(double(RFLUX),SMOOTHWINDOW*multiplierFLUX,2);
  HFLUX1 = smooth2a(double(HFLUX1),SMOOTHWINDOW*multiplierFLUX,2);
  RFLUX1 = smooth2a(double(RFLUX1),SMOOTHWINDOW*multiplierFLUX,2);
  HFLUX2 = smooth2a(double(HFLUX2),SMOOTHWINDOW*multiplierFLUX,2);
  RFLUX2 = smooth2a(double(RFLUX2),SMOOTHWINDOW*multiplierFLUX,2);
  HFLUX12 = smooth2a(double(HFLUX12),SMOOTHWINDOW*multiplierFLUX,2);
  RFLUX12 = smooth2a(double(RFLUX12),SMOOTHWINDOW*multiplierFLUX,2);
  %RFLUX_OAFLUX = smooth2a(double(RFLUX_OAFLUX),SMOOTHWINDOW*multiplierFLUX_OAFLUX,2);
  U     = smooth2a(double(U  ),SMOOTHWINDOW*multiplierU,   2);
%  FLUXH = smooth2a(double(FLUXH),SMOOTHWINDOW*multiplierVARS,   2);
%  FLUXV = smooth2a(double(FLUXV),SMOOTHWINDOW*multiplierVARS,   2);
%  uDmrDlon = smooth2a(double(uDmrDlon),SMOOTHWINDOW*multiplierVARS,   2);
%  vDmrDlat = smooth2a(double(vDmrDlat),SMOOTHWINDOW*multiplierVARS,   2);
end
dSFdt = (SF(3:end,:)-SF(1:end-2,:))/(1/multiplierVARS);
dSFdt = [dSFdt(1,:); dSFdt; dSFdt(end,:)];
dSFdt  = smooth2a(double(dSFdt ),SMOOTHWINDOW*multiplierVARS,3);

% this if statement is used for extracting the 0 to 5N DYNAMO data
% used with commenting out line with OLRfilt above
if 0
t = 4347;
lonRange = Ulon<80 & Ulon>70;
% second DYNAMO case
field = U((t-30)*multiplierU:(t+30)*multiplierU,lonRange);
Utime = -30:1/multiplierU:30;
U2 = mean(field,2);
% first DYNAMO case
field = U((t-30-28)*multiplierU:(t+30-28)*multiplierU,lonRange);
U1 = mean(field,2);
save -mat7-binary plot5_DYNAMO2_0_5_70_80.mat U1 Utime U2
stop
end


if 1
% get positions of minima of filtered OLR
index = minimaOLR(OLRfilt);
index = index(index(:,1)>LON1 & index(:,1)<=LON2, :);
%index = index(index(:,3)>-13, :); % use only MJOs with OLR greater than -10 W/ms (the weaker ones)
%index = index(index(:,3)<-13, :); % use only MJOs with OLR less than -10 W/ms (the STRONGER ones)

% remove MJOs within last 30 days or first 50 days,
% they mess up the averaging process, but we assume
% one or two MJOs don't make a difference in the 
% final result
index(index(:,2)<51,:) = [];
index(index(:,2)>length(OLRtime)*multiplierOLR-31,:) = [];
%if we want to EXCLUDE a portion of the data
if EXCLUDE
  if EXCLUDE_WEAKER
    index = index(index(:,3)<OLRcutoff,:);
  else
    index = index(index(:,3)>=OLRcutoff,:);
  end
end

index(index(:,2) == 708,:) = [];
index(index(:,2) == 1062,:) = [];
index(index(:,2) == 2372,:) = [];
index(index(:,2) == 2412,:) = [];
index(index(:,2) == 5609,:) = [];
index(index(:,2) == 5929,:) = [];
index(index(:,2) == 5989,:) = [];




indexTMP = index;
index = zeros(length(index),5);
index(:,1:3) = indexTMP;

for i = 1:length(index)
    indT = find(index(i,2)==Utime);
    Umm = mean(U_filt(indT,:));
    UmmB = mean(mean(U_filt(indT-10:indT+10,:)));
    index(i,4) = Umm;
    index(i,5) = UmmB;
end

indexSort = sortrows(index,4);
N = length(indexSort);


indexSortHIG = indexSort(1:floor(N/4),:);
mean(indexSortHIG(:,4))
mean(indexSortHIG(:,5))

indexSortLOW = indexSort(end-floor(N/4)+1:end,:);
mean(indexSortLOW(:,4))
mean(indexSortLOW(:,5))


index = indexSortLOW;
INDEXLABEL = 'LANCZOS_LOWzonalwinds';

%index = indexSortHIG;
%INDEXLABEL = 'LANCZOS_HIGHzonalwinds';

% all cases
%INDEXLABEL = 'LANCZOS';

%figure('visible','off')
%[N1,X1] = hist(indexSortLOW(:,1));
%[N2,X2] = hist(indexSortHIG(:,1));
%plot(X1,N1,'k',X2,N2,'r');
%legend('Q1','Q4')
%xlabel('longitude (deg)')
%ylabel('N')
%print(['filteredU_histogramU_LOWvsHIGlongitude.png'],'-dpng')
%stop



%debug
if 0
PREF = 'unAND';
%[N1,X1] = hist(indexSortLOW(:,3));
%[N2,X2] = hist(indexSortHIG(:,3));
%plot(X1,N1,'k',X2,N2,'r');
%legend('Q1','Q4')
%xlabel('filtered OLR minimum (W/m^2)')
%ylabel('N')
%print([PREF 'filteredU_histogramOLR.png'],'-dpng')
[N1,X1] = hist(index(:,4));
[N2,X2] = hist(index(:,5));
plot(X1,N1,'k',X2,N2,'r');
legend('original','low pass filtered')
xlabel('zonal wind (m/s)')
ylabel('N')
print([PREF 'filteredU_histogramU.png'],'-dpng')
stop
end



% FILTERING the selected OLR minima
if 0
% Use only warm pool data 
index = index(index(:,1)>0 & index(:,1)<200, :);
%length(index) % brings from 190 identified to 177
% Exclude successive MJOs, i.e. find MJOs which don't have a MJO in the 30 days preceding it
indexTMP = [];
for i = 1:length(index)
  timeIND = index(i,2);
  if sum(index(:,2) > timeIND-40 & index(:,2)< timeIND) == 0
    indexTMP = [indexTMP; index(i,:) ];
  end
end
length(indexTMP)
index=indexTMP;
FILTERindexLABEL = 'warmPoolAndExlude40dayPrevious';
%stop
end
FILTERindexLABEL = 'noExclusions';


if 0
% plot the histogram of OLR strengths
figure
  subplot(1,2,1)
hist(index(:,3),-38:2:0,'facecolor','none')
ylabel('N','fontsize',12)
xlabel('OLR minimum (W/m^2)','fontsize',12)
xlim([-38 0])
set(gca,'fontsize',12)
  subplot(1,2,2)
hist(index(:,1),0:10:360,'facecolor','none')
ylabel('N','fontsize',12)
xlabel('longitude position (deg)','fontsize',12)
xlim([0 360])
set(gca,'fontsize',12)
%print('PRODUCTIONcountStrength.eps','-S400,300','-depsc')
%length(index)
%sum(index(:,3)<-17)
%stop
end
end % if 0

















% OLR versus mean(U) 10 days before
if 0

correlations = [];
for t1 = -20:-1
  t2=t1+1;
  data = [];
  for i = 1:size(index,1)
    posLon  = index(i,1);
    t = index(i,2);
    field = mean(mean(U((t+t1)*multiplierU:(t+t2)*multiplierU,:)));
    if index(i,3) > -35
      data = [ data; index(i,3) field ];
    end
  end
  x = data(:,1);
  y = data(:,2);
  if t1 == -10
    figure('rend','painters','pos',[10 10 350 450])
    X = [ones(length(x),1) x];
    b = X\y;
    yCalc2 = X*b;
    subplot(2,1,2)
    plot(x,y,'k.','markerSize',13);hold on;
    plot(x,yCalc2,'k','linewidth',2)
    %legend('Data','Linear Fit','Location','best')
    xlabel('filtered OLR minimum amplitude (W m^{-2})')
    ylabel('<U> (m s^{})')
 %   title('t = -6 d, R = 0.52')
    corr(x,y)
  end
  R = corr(x,y);
  correlations = [ correlations; R ];
end
subplot(2,1,1)
plot(-20:-1,correlations,'k','linewidth',2);hold on;
xlabel('time (days before OLR minimum)')
ylabel('R')



correlations = [];
for t1 = -20:-1
  t2=t1+1;
  data = [];
  for i = 1:size(index,1)
    posLon  = index(i,1);
    t = index(i,2);
    field = mean(mean(U((t+t1)*multiplierU:(t+t2)*multiplierU,:)));
    if index(i,3) < -15 & index(i,3) > -35
      data = [ data; index(i,3) field ];
    end
  end
  x = data(:,1);
  y = data(:,2);
  if t1 == -10
    X = [ones(length(x),1) x];
    b = X\y;
    yCalc2 = X*b;
    subplot(2,1,2)
    plot(x,y,'r.','markerSize',13);hold on;
    plot(x,yCalc2,'r','linewidth',2)
    %legend('Data','Linear Fit','Location','best')
    xlabel('filtered OLR minimum amplitude (W m^{-2})')
    ylabel('<U> (m s^{})')
    title('R = 0.34, \color{red}R = 0.52')
    
    corr(x,y)
  end
  R = corr(x,y);
  correlations = [ correlations; R ];
end
subplot(2,1,1)
plot(-20:-1,correlations,'r','linewidth',2);hold on;
    plot([-10 -10],[0.2 0.6],'k','linewidth',1)
xlabel('time (days before OLR minimum)')
ylabel('R')
legend('OLR < 0','OLR< -15') %,'Location','northoutside')




stop
end







%hist(index,-30:0)
%length(index)
%length(index(index(:,3)<-18,:))
%stop

% for plotting average of zonal wind 
if 0
dateVectorVar = dateVectorFunctionVar(year1n,year2n,multiplierU,0);
[yearMean, yearDJF, yearMAM, yearJJA, yearSON] = varYearly(year1n, year2n, U, dateVectorVar, multiplierU);
mean1 = movingmean(mean(yearMean,2),20,1,[]);
meanS = movingmean(std(yearMean,0,2),20,1,[]);
meanM = movingmean(std(yearMean,0,2),20,1,[]);
time1 = 1/multiplierU:1/multiplierU:365;
save('-mat',['zonalWindYearlyAverage_' year1 '_' year2 '_' lat1 '_' lat2 '_' DATA '.mat'],'mean1','meanS','meanM','time1');
stop
end

















% N of MJOs
numMJOs = length(index)
indexORIG = index;
% divide indexed data into months, DJF is December, January, and February, etc.
[indexDJF, indexMAM, indexJJA, indexSON] = indexingMonths(index,dateVector);

CENTER = 1; 
LOCALMEAN = 0;
PERIOD = 'DJF'; index = indexDJF;
[U_D, SF_D, II_D, OLR_D, ...
RFLUX_D, RFLUX1_D, RFLUX2_D, RFLUX12_D, RFLUX_OAFLUX_D, vDmrDlat_D, uDmrDlon_D, ...
U_D_M, SF_D_M, II_D_M, OLR_D_M, ...
RFLUX_D_M, RFLUX1_D_M, RFLUX2_D_M, RFLUX12_D_M, RFLUX_OAFLUX_D_M, vDmrDlat_D_M, uDmrDlon_D_M] = ...
analyseAll(year1n,year2n,index,CENTER,PERIOD,LOCALMEAN, U, Utime, Ulon, SF, SFtime, SFlon, II, IItime, ...
IIlon, OLR, OLRtime, OLRlon, RFLUX, RFLUX1, RFLUX2, RFLUX12, RFLUX_OAFLUX, vDmrDlat, FLUXlon, FLUXtime, FLUXlon1, FLUXtime1, FLUXlon_OAFLUX, FLUXtime_OAFLUX, vDmrDlatlon, vDmrDlattime, uDmrDlon, uDmrDlonlon, uDmrDlontime, ...
multiplierOLR, multiplierVARS, multiplierU, multiplierFLUX, multiplierFLUX_OAFLUX, MODELS);

PERIOD = 'MAM'; index = indexMAM;
[U_M, SF_M, II_M, OLR_M, ...
RFLUX_M, RFLUX1_M, RFLUX2_M, RFLUX12_M, RFLUX_OAFLUX_M, vDmrDlat_M, uDmrDlon_M, ...
U_M_M, SF_M_M, II_M_M, OLR_M_M, ...
RFLUX_M_M, RFLUX1_M_M, RFLUX2_M_M, RFLUX12_M_M, RFLUX_OAFLUX_M_M, vDmrDlat_M_M, uDmrDlon_M_M] = ...
analyseAll(year1n,year2n,index,CENTER,PERIOD,LOCALMEAN, U, Utime, Ulon, SF, SFtime, SFlon, II, IItime, ...
IIlon, OLR, OLRtime, OLRlon, RFLUX, RFLUX1, RFLUX2, RFLUX12, RFLUX_OAFLUX, vDmrDlat, FLUXlon, FLUXtime, FLUXlon1, FLUXtime1, FLUXlon_OAFLUX, FLUXtime_OAFLUX, vDmrDlatlon, vDmrDlattime, uDmrDlon, uDmrDlonlon, uDmrDlontime, ...
multiplierOLR, multiplierVARS, multiplierU, multiplierFLUX, multiplierFLUX_OAFLUX, MODELS);

PERIOD = 'JJA'; index = indexJJA;
[U_J, SF_J, II_J, OLR_J, ...
RFLUX_J, RFLUX1_J, RFLUX2_J, RFLUX12_J, RFLUX_OAFLUX_J, vDmrDlat_J, uDmrDlon_J, ...
U_J_M, SF_J_M, II_J_M, OLR_J_M, ...
RFLUX_J_M, RFLUX1_J_M, RFLUX2_J_M, RFLUX12_J_M, RFLUX_OAFLUX_J_M, vDmrDlat_J_M, uDmrDlon_J_M] = ...
analyseAll(year1n,year2n,index,CENTER,PERIOD,LOCALMEAN, U, Utime, Ulon, SF, SFtime, SFlon, II, IItime, ...
IIlon, OLR, OLRtime, OLRlon, RFLUX, RFLUX1, RFLUX2, RFLUX12, RFLUX_OAFLUX, vDmrDlat, FLUXlon, FLUXtime, FLUXlon1, FLUXtime1, FLUXlon_OAFLUX, FLUXtime_OAFLUX, vDmrDlatlon, vDmrDlattime, uDmrDlon, uDmrDlonlon, uDmrDlontime, ...
multiplierOLR, multiplierVARS, multiplierU, multiplierFLUX, multiplierFLUX_OAFLUX, MODELS);

PERIOD = 'SON'; index = indexSON;
[U_S, SF_S, II_S, OLR_S, ...
RFLUX_S, RFLUX1_S, RFLUX2_S, RFLUX12_S, RFLUX_OAFLUX_S, vDmrDlat_S, uDmrDlon_S, ...
U_S_M, SF_S_M, II_S_M, OLR_S_M, ...
RFLUX_S_M, RFLUX1_S_M, RFLUX2_S_M, RFLUX12_S_M, RFLUX_OAFLUX_S_M, vDmrDlat_S_M, uDmrDlon_S_M] = ...
analyseAll(year1n,year2n,index,CENTER,PERIOD,LOCALMEAN, U, Utime, Ulon, SF, SFtime, SFlon, II, IItime, ...
IIlon, OLR, OLRtime, OLRlon, RFLUX, RFLUX1, RFLUX2, RFLUX12, RFLUX_OAFLUX, vDmrDlat, FLUXlon, FLUXtime, FLUXlon1, FLUXtime1, FLUXlon_OAFLUX, FLUXtime_OAFLUX, vDmrDlatlon, vDmrDlattime, uDmrDlon, uDmrDlonlon, uDmrDlontime, ...
multiplierOLR, multiplierVARS, multiplierU, multiplierFLUX, multiplierFLUX_OAFLUX, MODELS);

index = indexORIG;


% for fields where the climatology WAS removed!
ALL_Up    = concatField(size(U_D,1),size(U_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), U_D, U_M, U_J, U_S);
ALL_SFp   = concatField(size(SF_D,1),size(SF_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), SF_D, SF_M, SF_J, SF_S);
ALL_IIp   = concatField(size(II_D,1),size(II_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), II_D, II_M, II_J, II_S);
ALL_OLRp  = concatField(size(OLR_D,1),size(OLR_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), OLR_D, OLR_M, OLR_J, OLR_S);
ALL_RFLUXp  = concatField(size(RFLUX_D,1),size(RFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), RFLUX_D, RFLUX_M, RFLUX_J, RFLUX_S);
ALL_RFLUX1p  = concatField(size(RFLUX1_D,1),size(RFLUX1_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), RFLUX1_D, RFLUX1_M, RFLUX1_J, RFLUX1_S);
ALL_RFLUX2p  = concatField(size(RFLUX2_D,1),size(RFLUX2_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), RFLUX2_D, RFLUX2_M, RFLUX2_J, RFLUX2_S);
ALL_RFLUX12p  = concatField(size(RFLUX12_D,1),size(RFLUX12_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), RFLUX12_D, RFLUX12_M, RFLUX12_J, RFLUX12_S);
ALL_RFLUX_OAFLUXp  = concatField(size(RFLUX_OAFLUX_D,1),size(RFLUX_OAFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), RFLUX_OAFLUX_D, RFLUX_OAFLUX_M, RFLUX_OAFLUX_J, RFLUX_OAFLUX_S);
vDmrDlatp  = concatField(size(vDmrDlat_D,1),size(vDmrDlat_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), vDmrDlat_D, vDmrDlat_M, vDmrDlat_J, vDmrDlat_S);
uDmrDlonp  = concatField(size(uDmrDlon_D,1),size(uDmrDlon_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), uDmrDlon_D, uDmrDlon_M, uDmrDlon_J, uDmrDlon_S);


% ALL_FLUXHp  = concatField(size(FLUXH_D,1),size(RFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA), FLUXH_D, FLUXH_M, FLUXH_J, FLUXH_S);
% ALL_FLUXVp  = concatField(size(FLUXV_D,1),size(HFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA), FLUXV_D, FLUXV_M, FLUXV_J, FLUXV_S);
% ALL_uDmrDlonP  = concatField(size(uDmrDlon_D,1),size(RFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA), uDmrDlon_D, uDmrDlon_M, uDmrDlon_J, uDmrDlon_S);
% ALL_vDmrDlatP  = concatField(size(vDmrDlat_D,1),size(HFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA), vDmrDlat_D, vDmrDlat_M, vDmrDlat_J, vDmrDlat_S);

% SF, take partial time derivative
dSFdtp = (ALL_SFp(3:end,:,:)-ALL_SFp(1:end-2,:,:))/(1/multiplierVARS);
% II, take partial time derivative
dIIdtp = (ALL_IIp(3:end,:,:)-ALL_IIp(1:end-2,:,:))/(1/multiplierVARS);

% for fields where the climatology was not removed!
ALL_U    = concatField(size(U_D,1),size(U_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), U_D_M, U_M_M, U_J_M, U_S_M);
ALL_SF   = concatField(size(SF_D,1),size(SF_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), SF_D_M, SF_M_M, SF_J_M, SF_S_M);
ALL_II   = concatField(size(II_D,1),size(II_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), II_D_M, II_M_M, II_J_M, II_S_M);
ALL_OLR  = concatField(size(OLR_D,1),size(OLR_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), OLR_D_M, OLR_M_M, OLR_J_M, OLR_S_M);
ALL_RFLUX  = concatField(size(RFLUX_D,1),size(RFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), RFLUX_D_M, RFLUX_M_M, RFLUX_J_M, RFLUX_S_M);
ALL_RFLUX1  = concatField(size(RFLUX1_D,1),size(RFLUX1_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), RFLUX1_D_M, RFLUX1_M_M, RFLUX1_J_M, RFLUX1_S_M);
ALL_RFLUX2  = concatField(size(RFLUX2_D,1),size(RFLUX2_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), RFLUX2_D_M, RFLUX2_M_M, RFLUX2_J_M, RFLUX2_S_M);
ALL_RFLUX12  = concatField(size(RFLUX12_D,1),size(RFLUX12_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), RFLUX12_D_M, RFLUX12_M_M, RFLUX12_J_M, RFLUX12_S_M);
ALL_RFLUX_OAFLUX  = concatField(size(RFLUX_OAFLUX_D,1),size(RFLUX_OAFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), RFLUX_OAFLUX_D_M, RFLUX_OAFLUX_M_M, RFLUX_OAFLUX_J_M, RFLUX_OAFLUX_S_M);

% ALL_FLUXH  = concatField(size(FLUXH_D,1),size(RFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), FLUXH_D_M, FLUXH_M_M, FLUXH_J_M, FLUXH_S_M);
% ALL_FLUXV  = concatField(size(FLUXV_D,1),size(HFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), FLUXV_D, FLUXV_M_M, FLUXV_J_M, FLUXV_S_M);
% ALL_uDmrDlon  = concatField(size(uDmrDlon_D,1),size(RFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), uDmrDlon_D_M, uDmrDlon_M_M, uDmrDlon_J_M, uDmrDlon_S_M);
% ALL_vDmrDlat  = concatField(size(vDmrDlat_D,1),size(HFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), vDmrDlat_D_M, vDmrDlat_M_M, vDmrDlat_J_M, vDmrDlat_S_M);


dSFdt0 = dSFdt;
% smooth SF and take partial time derivative 
dSFdt = (ALL_SF(3:end,:,:)-ALL_SF(1:end-2,:,:))/(1/multiplierVARS);
% smooth II and take partial time derivative 
dIIdt = (ALL_II(3:end,:,:)-ALL_II(1:end-2,:,:))/(1/multiplierVARS);


% [Hup,Pup] = statTestFunct(ALL_Up);
% [Hsfp,Psfp] = statTestFunct(ALL_SFp);
% [Hdsfdtp,Pdsfdtp] = statTestFunct(dSFdt);
% [Hrfluxp,Prfluxp] = statTestFunct(ALL_RFLUXp);
% [Hhfluxp,Phfluxp] = statTestFunct(ALL_HFLUXp);

%[Hu,Pu] = statTestFunctFULL(ALL_U,U);
%[Hsf,Psf] = statTestFunctFULL(ALL_SF,SF);
%[Hrflux,Prflux] = statTestFunctFULL(ALL_RFLUX,RFLUX);

%close all;

Pup = statTestFunct(ALL_Up);
Psfp = statTestFunct(ALL_SFp);
Pdsfdtp = statTestFunct(dSFdt);
Prfluxp = statTestFunct(ALL_RFLUXp);
Prflux1p = statTestFunct(ALL_RFLUX1p);
Prflux2p = statTestFunct(ALL_RFLUX2p);
Prflux12p = statTestFunct(ALL_RFLUX12p);
Prflux_Op = statTestFunct(ALL_RFLUX_OAFLUXp);
PvDmrDlatp = statTestFunct( vDmrDlatp);
PuDmrDlonp = statTestFunct( uDmrDlonp);

pp = 0.05;

Hup = Pup   > pp;
Hsfp = Psfp > pp;
Hdsfdtp = Pdsfdtp > pp;
Hrfluxp = Prfluxp > pp;
Hrflux1p = Prflux1p > pp;
Hrflux2p = Prflux2p > pp;
Hrflux12p = Prflux12p > pp;
Hrflux_Op = Prflux_Op > pp;
HvDmrDlatp = PvDmrDlatp > pp;
HuDmrDlonp = PuDmrDlonp > pp;


end % RELOAD if statement



% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Until here processing files and analysis











plotStd = 0; 

if 0
    
% figure('rend','painters','pos',[10 10 500 800]) %,'visible','off')
%   subplot(4,1,1); plotSubplotDeriv(ALL_Up, Ulon, multiplierU, -2, .5, 2, 'time (d)', '', 'a) $\mathrm{\Delta U\ (m\ s^{-1})}$',Hup);
%   subplot(4,1,2); plotSubplotDeriv(ALL_SFp, SFlon, multiplierVARS, -2, .5, 2, 'time (d)', '','b) $\mathrm{\Delta m_r\ (g\ kg^{-1})}$',Hsfp);
%   subplot(4,1,3); plotSubplotDeriv(vDmrDlatp, vDmrDlatlon, multiplierVARS, 0,0,0, 'time (d)', '', ...
%                                        'c) $\mathrm{\partial m_r/\partial t\ [100-850 hPa]\ (g\ kg^{-1}d^{-1})}$',HvDmrDlatp);
%   subplot(4,1,4); plotSubplotDeriv(uDmrDlonp, uDmrDlonlon, multiplierVARS, 0,0,0, 'time (d)', 'longitude (deg)', ...
%                                        'd) $\mathrm{\partial m_r/\partial t\ [850-1000 hPa]\ (g\ kg^{-1}d^{-1})}$',HuDmrDlonp);
% print(['REV_figure4x_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.png'],'-dpng')
% print(['REV_figure4x_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.eps'],'-depsc')


figure('rend','painters','pos',[10 10 500 800],'visible','off')
  subplot(4,1,1); plotSubplotStat(ALL_Up, Ulon, multiplierU, -2, .5, 2, 'time (d)', '', 'a) $\mathrm{\Delta U\ (m\ s^{-1})}$',plotStd,Hup,-2.5,2.5);
  subplot(4,1,2); plotSubplotStat(ALL_SFp, SFlon, multiplierVARS, -2, .5, 2, 'time (d)', '','b) $\mathrm{\Delta m_r\ (g\ kg^{-1})}$',plotStd,Hsfp,-0.5,0.5);
  subplot(4,1,3); plotSubplotStat(vDmrDlatp, vDmrDlatlon, multiplierVARS, 0,0,0, 'time (d)', '', ...
                                       'c) $\mathrm{\partial m_r/\partial t\ [100-850 hPa]\ (g\ kg^{-1}d^{-1})}$',plotStd,HvDmrDlatp,-0.11,0.11);
  subplot(4,1,4); plotSubplotStat(uDmrDlonp, uDmrDlonlon, multiplierVARS, 0,0,0, 'time (d)', 'longitude (deg)', ...
                                       'd) $\mathrm{\partial m_r/\partial t\ [850-1000 hPa]\ (g\ kg^{-1}d^{-1})}$',plotStd,HuDmrDlonp,-0.11,0.11);
print(['REV_figure4_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.png'],'-dpng')
print(['REV_figure4_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.eps'],'-depsc')


figure('rend','painters','pos',[10 10 500 800],'visible','off')

  subplot(4,1,1);
  plotSubplotStat(ALL_RFLUX_OAFLUXp, FLUXlon_OAFLUX, multiplierFLUX_OAFLUX, -2, .5, 2, 'time (d)', '','a) OAFlux $\mathrm{\Delta F\ (W\ m^{-2})}$',plotStd,Hrflux_Op,-25,20);

  subplot(4,1,2);
  plotSubplotStat(ALL_RFLUXp, FLUXlon, multiplierFLUX, -2, .5, 2, 'time (d)', '','b) FNL $\mathrm{\Delta F\ (W\ m^{-2})}$',plotStd,Hrfluxp,-25,20);

  subplot(4,1,3);
  plotSubplotStat(ALL_RFLUX1p, FLUXlon1, multiplierFLUX, -2, .5, 2, 'time (d)', '','c) FNL zonal $\mathrm{\Delta F_{Z}\ (W\ m^{-2})}$',plotStd,Hrflux1p,-25,20);

  subplot(4,1,4);
  plotSubplotStat(ALL_RFLUX2p, FLUXlon1, multiplierFLUX, -2, .5, 2, 'time (d)', 'longitude (deg)','d) FNL meridional $\mathrm{\Delta F_{M}\ (W\ m^{-2})}$',plotStd,Hrflux2p,-25,20);

print(['REV_figure9_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.png'],'-dpng')
print(['REV_figure9_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.eps'],'-depsc')

stop
end %if


if 0
figure('rend','painters','pos',[10 10 500 800],'visible','off')

  subplot(4,1,1);
  plotSubplotStat(ALL_RFLUX_OAFLUXp, FLUXlon_OAFLUX, multiplierFLUX_OAFLUX, -2, .5, 2, 'time (d)', '','a) OAFlux $\mathrm{\Delta F\ (W\ m^{-2})}$',plotStd,Hrflux_Op,-25,20);

  subplot(4,1,2);
  plotSubplotStat(ALL_RFLUXp, FLUXlon, multiplierFLUX, -2, .5, 2, 'time (d)', '','b) FNL $\mathrm{\Delta F\ (W\ m^{-2})}$',plotStd,Hrfluxp,-25,20);

  subplot(4,1,3);
  plotSubplotStat(ALL_RFLUX1p, FLUXlon1, multiplierFLUX, -2, .5, 2, 'time (d)', '','c) FNL zonal $\mathrm{\Delta F_{Z}\ (W\ m^{-2})}$',plotStd,Hrflux1p,-25,20);

  subplot(4,1,4);
  plotSubplotStat(ALL_RFLUX2p, FLUXlon1, multiplierFLUX, -2, .5, 2, 'time (d)', 'longitude (deg)','d) FNL meridional $\mathrm{\Delta F_{M}\ (W\ m^{-2})}$',plotStd,Hrflux2p,-25,20);

print(['REV_figure10_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.png'],'-dpng')
print(['REV_figure10_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.eps'],'-depsc')



stop
end %if


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% low zonal winds

if 1

figure('rend','painters','pos',[10 10 500 800],'visible','off')
  subplot(4,1,1); plotSubplotStat(ALL_Up, Ulon, multiplierU, -2, .5, 2, 'time (d)', '', 'a) Q1 $\mathrm{\Delta U\ (m\ s^{-1})}$',plotStd,Hup,-2.5,2.5);
  subplot(4,1,2); plotSubplotStat(ALL_SFp, SFlon, multiplierVARS, -2, .5, 2, 'time (d)', '','b) Q1 $\mathrm{\Delta m_r\ (g\ kg^{-1})}$',plotStd,Hsfp,-0.5,0.5);
  subplot(4,1,3); plotSubplotStat(vDmrDlatp, vDmrDlatlon, multiplierVARS, 0,0,0, 'time (d)', '', ...
                                       'c) Q1 $\mathrm{\partial m_r/\partial t\ [100-850 hPa]\ (g\ kg^{-1}d^{-1})}$',plotStd,HvDmrDlatp,-0.11,0.11);
  subplot(4,1,4); plotSubplotStat(uDmrDlonp, uDmrDlonlon, multiplierVARS, 0,0,0, 'time (d)', 'longitude (deg)', ...
                                       'd) Q1 $\mathrm{\partial m_r/\partial t\ [850-1000 hPa]\ (g\ kg^{-1}d^{-1})}$',plotStd,HuDmrDlonp,-0.11,0.11);
print(['REV_figure4_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.png'],'-dpng')
print(['REV_figure4_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.eps'],'-depsc')


figure('rend','painters','pos',[10 10 500 800] ,'visible','off')

  subplot(4,1,1);
  plotSubplotStat(ALL_RFLUX_OAFLUXp, FLUXlon_OAFLUX, multiplierFLUX_OAFLUX, -2, .5, 2, 'time (d)', '','a) OAFlux Q1 $\mathrm{\Delta F\ (W\ m^{-2})}$',plotStd,Hrflux_Op,-25,20);
  subplot(4,1,2);
  plotSubplotStat(ALL_RFLUXp, FLUXlon, multiplierFLUX, -2, .5, 2, 'time (d)', '','b) FNL Q1 $\mathrm{\Delta F\ (W\ m^{-2})}$',plotStd,Hrfluxp,-25,20);
  subplot(4,1,3);
  plotSubplotStat(ALL_RFLUX1p, FLUXlon1, multiplierFLUX, -2, .5, 2, 'time (d)', '','c) FNL Q1 zonal $\mathrm{\Delta F_{Z}\ (W\ m^{-2})}$',plotStd,Hrflux1p,-25,20);
  subplot(4,1,4);
  plotSubplotStat(ALL_RFLUX2p, FLUXlon1, multiplierFLUX, -2, .5, 2, 'time (d)', 'longitude (deg)','d) FNL Q1 meridional $\mathrm{\Delta F_{M}\ (W\ m^{-2})}$',plotStd,Hrflux2p,-25,20);

print(['REV_figure9_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.png'],'-dpng')
print(['REV_figure9_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.eps'],'-depsc')
stop
end %if



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% high zonal winds

if 0

figure('rend','painters','pos',[10 10 500 800],'visible','off')
  subplot(4,1,1); plotSubplotStat(ALL_Up, Ulon, multiplierU, -2, .5, 2, '', '', 'e) Q4 $\mathrm{\Delta U\ (m\ s^{-1})}$',plotStd,Hup,-2.5,2.5);
  subplot(4,1,2); plotSubplotStat(ALL_SFp, SFlon, multiplierVARS, -2, .5, 2, '', '','f) Q4 $\mathrm{\Delta m_r\ (g\ kg^{-1})}$',plotStd,Hsfp,-0.5,0.5);
  subplot(4,1,3); plotSubplotStat(vDmrDlatp, vDmrDlatlon, multiplierVARS, 0,0,0, '', '', ...
                                       'g) Q4 $\mathrm{\partial m_r/\partial t\ [100-850 hPa]\ (g\ kg^{-1}d^{-1})}$',plotStd,HvDmrDlatp,-0.11,0.11);
  subplot(4,1,4); plotSubplotStat(uDmrDlonp, uDmrDlonlon, multiplierVARS, 0,0,0, '', 'longitude (deg)', ...
                                       'h) Q4 $\mathrm{\partial m_r/\partial t\ [850-1000 hPa]\ (g\ kg^{-1}d^{-1})}$',plotStd,HuDmrDlonp,-0.11,0.11);
print(['REV_figure4_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.png'],'-dpng')
print(['REV_figure4_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.eps'],'-depsc')


figure('rend','painters','pos',[10 10 500 800],'visible','off')

  subplot(4,1,1);
  plotSubplotStat(ALL_RFLUX_OAFLUXp, FLUXlon_OAFLUX, multiplierFLUX_OAFLUX, -2, .5, 2, 'time (d)', '','e) OAFlux Q4 $\mathrm{\Delta F\ (W\ m^{-2})}$',plotStd,Hrflux_Op,-25,20);
  subplot(4,1,2);
  plotSubplotStat(ALL_RFLUXp, FLUXlon, multiplierFLUX, -2, .5, 2, '', '','f) FNL Q4 $\mathrm{\Delta F\ (W\ m^{-2})}$',plotStd,Hrfluxp,-25,20);
  subplot(4,1,3);
  plotSubplotStat(ALL_RFLUX1p, FLUXlon1, multiplierFLUX, -2, .5, 2, '', '','g) FNL Q4 zonal $\mathrm{\Delta F_{Z}\ (W\ m^{-2})}$',plotStd,Hrflux1p,-25,20);
  subplot(4,1,4);
  plotSubplotStat(ALL_RFLUX2p, FLUXlon1, multiplierFLUX, -2, .5, 2, '', 'longitude (deg)','h) FNL Q4 meridional $\mathrm{\Delta F_{M}\ (W\ m^{-2})}$',plotStd,Hrflux2p,-25,20);

print(['REV_figure9_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.png'],'-dpng')
print(['REV_figure9_' INDEXLABEL '_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.eps'],'-depsc')
stop
end %if






























% plot single intersection
if 0

load fuchsModelFieldsV7.mat;
figure('rend','painters','pos',[10 10 450 350])
subplot(2,1,1)
uu = mean(ALL_Up,3); uu = uu(100,:);
sf = mean(ALL_SFp,3); sf = sf(100,:);
dsf = mean(dSFdtp,3); dsf = dsf(99,:);
mrflux = nanmean(ALL_RFLUXp,3); mrflux = mrflux(50,:);
hflux = nanmean(ALL_HFLUXp,3); hflux = hflux(50,:);
plot(Ulon-180,uu/max(abs(uu)),'r','lineWidth',2); hold on;
plot(SFlon-180,sf/max(sf),'b','lineWidth',2)
plot(SFlon-180,dsf/abs(min(dsf)),'k','lineWidth',2)
plot(FLUXlon-180,mrflux/max(abs(mrflux)),'m','lineWidth',2); hold on;
%plot(FLUXlon-180,hflux/max(abs(hflux)),'g','lineWidth',2); hold on;
plot(SFlon-180,0*dsf/abs(min(dsf)),'k','lineWidth',1)
plot([0 0],[-1.1 1.5],'k--','LineWidth',1)
%h = legend('\DeltaU','\DeltaSF','\partialSF/\partialt','l.h. flux','s.h. flux');
h = legend('\DeltaU','\DeltaSF','\partialSF/\partialt','l.h. flux');
set(h,'position',[0.80 .92 0.15 0.0],'fontsize', 8)
ylabel('', 'fontsize', 12)
xlabel('longitude lag (deg)','fontsize', 12)
%title('perturbations from FNL reanalysis', 'fontsize', 12)
xlim([-180 180])
ylim([-1.1 1.5])
text(-167,1.12,'a)', 'fontsize',11)
set(gca, 'fontsize', 12)

subplot(2,1,2)
plot(x-pi,ur/max(ur),'r','lineWidth',2); hold on;
plot(x-pi,qr/abs(min(qr)),'b','lineWidth',2)
plot(x-pi,dqdtr/max(dqdtr),'k','lineWidth',2)
plot(x-pi,-ur/max(ur),'m','lineWidth',2)
plot(x-pi,ur*0,'k')
plot([0 0],[-1.1 1.5],'k--','LineWidth',1)
h = legend('\DeltaU','\Deltaq','\partialq/\partialt','l.h. flux');
set(h,'position',[0.80 .485 0.15 0.0],'fontsize', 8)
ylabel('', 'fontsize', 12)
xlabel('non-dimensional longitude lag', 'fontsize', 12)
%title('perturbations from Fuchs and Raymond (2017)', 'fontsize', 12)
set(gca,'fontsize',12)
xlim([-pi pi])
ylim([-1.1 1.5])
text(-2.9,1.12,'b)', 'fontsize',11)

 print(['REVIEW_PRODUCTION_figure6_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.eps'],'-depsc')
 print(['REVIEW_PRODUCTION_figure6_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.png'],'-dpng')



% Upert = nanmean(ALL_Up,3);
% Up = Upert(:,180);
% SFpert = nanmean(ALL_SFp,3);
% SFp = SFpert(:,180);
% dSFdtpert = nanmean(dSFdtp,3);
% RFLUXp = nanmean(ALL_RFLUXp,3);
% dSdtp = dSFdtpert(:,180);
% timeP = -50:1/multiplierU:30;



% Upert = nanmean(ALL_Up,3).*Hup;
% Up = Upert(:,180);
% SFpert = nanmean(ALL_SFp,3).*Hsfp;
% SFp = SFpert(:,180);
% dSFdtpert = nanmean(dSFdtp,3).*Hdsfdtp;
% RFLUXp = nanmean(ALL_RFLUXp,3).*Hrfluxp;
% HFLUXp = nanmean(ALL_HFLUXp,3).*Hhfluxp;
% dSFdtp = dSFdtpert(:,180);
% timeP = -50:1/multiplierU:30;
% RFLUXp = RFLUXp(:,180);
% HFLUXp = HFLUXp(:,180);
% timePflux = timeP(1:2:end);

Upert1 = nanmean(ALL_Up,3);
Up1 = Upert1(:,length(Ulon)/2);
SFpert1 = nanmean(ALL_SFp,3);
SFp1 = SFpert1(:,length(SFlon)/2);
dSFdtpert1 = nanmean(dSFdtp,3);
RFLUXp1 = nanmean(ALL_RFLUXp,3);
HFLUXp1 = nanmean(ALL_HFLUXp,3);
dSFdtp1 = dSFdtpert1(:,length(SFlon)/2);
timeP = -50:1/multiplierU:30;
RFLUXp1 = RFLUXp1(:,length(FLUXlon)/2);
HFLUXp1 = HFLUXp1(:,length(FLUXlon)/2);
timePflux = timeP(1:2:end);

if 0
    
save(['REVIEW_ModelCompData_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL '.mat'],...
    'Up1','SFp1','dSFdtp1','RFLUXp1','HFLUXp1','timeP','timePflux');

end


figure('rend','painters','pos',[10 10 450 350])

subplot(2,1,1)

%load EASTERLYpertTime.mat
lim1 = -30; multiplierU = 4;
lim2 =  30;
%N = size(Up,1);
%N1 = N - (lim2-lim1)*multiplierU;
%field = field(N1:N,:);
%tt = lim1:1/multiplierU:lim2;
timeP = -50:0.5:30;

pos1 = 25;
pos2 = 56;
pos3 = 81.5;
lineWidth = 2;
helpLineWidth = 1;
fontSize = 12;




plot(timeP,Up1/max(abs(Up1)),'r','lineWidth',lineWidth); hold on;
plot(timeP,SFp1/max(abs(SFp1)),'b','lineWidth',lineWidth)
plot(timeP(2:end-1),dSFdtp1/max(abs(dSFdtp1)),'k','lineWidth',lineWidth)
plot(timePflux,RFLUXp1/max(abs(RFLUXp1)),'m','lineWidth',lineWidth)
%plot(timePflux,HFLUXp1/max(abs(HFLUXp1)),'g','lineWidth',lineWidth)
plot(timeP,0*SFp1/max(abs(SFp1)),'k','lineWidth',helpLineWidth)
plot([0 0],[-1.1 1.5],'k--','LineWidth',helpLineWidth)
%h = legend('\DeltaU','\DeltaSF','\partialSF/\partialt','l.h. flux','s.h. flux');
h = legend('\DeltaU','\DeltaSF','\partialSF/\partialt','l.h. flux');
set(h,'position',[0.80 .90 0.14 0.0],'fontsize', 8)
ylabel('', 'fontsize', fontSize)
xlabel('time (d)', 'fontsize', fontSize)
text(-27,1.12,'a)', 'fontsize',11)
%title('reanalysis climatology', 'fontsize', fontSize)
set(gca,'fontsize',fontSize)
xlim([-30 30])
ylim([-1.1 1.5])

subplot(2,1,2)
%subplot(4,1,4)
load fuchsModelFieldsTimeDepPert.mat;
plot(timep,Uptime,'r','lineWidth',lineWidth); hold on;
plot(timep,qptime,'b','lineWidth',lineWidth)
plot(timep,dqdtptime,'k','lineWidth',lineWidth)
plot(timep,-Uptime,'m','lineWidth',lineWidth); hold on;
plot(timep,Uptime*0,'k','lineWidth',helpLineWidth)
plot([0 0],[-1.1 1.5],'k--','LineWidth',helpLineWidth)
h = legend('\DeltaU','\Deltaq','\partialq/\partialt','l.h. flux');
set(h,'position',[0.80 .485 0.15 0.0],'fontsize', 8)
ylabel('', 'fontsize', fontSize)
xlabel('non-dimensional time', 'fontsize', fontSize)
text(-4.1,1.12,'b)', 'fontsize',11)
%title('Fuchs and Raymond (2017)', 'fontsize', fontSize)
set(gca,'fontsize',fontSize)
xlim([-4.5 4.5])
ylim([-1.1 1.5])

print(['REVIEW_PRODUCTION_figure5_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL '.eps'],'-depsc')
print(['REVIEW_PRODUCTION_figure5_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.png'],'-dpng')


end



if 0

dt = 30;
t = [2254 3811 5675 4803 440 4425 5416 687 822 5821 3319 1810 3728 1251 5482 1890 5201 1832 5545 1787 1139 5792 1899 358];
t = index(:,2); 
OLRstrength = index(:,3);
for kk = 1:length(t)
  time1 = t(kk)-dt;
  time2 = t(kk)+dt;

  close all;
  figure('rend','painters','pos',[10 10 1400 900],'visible','off')
  fprintf('%i / %i \n', kk,length(t))

  colorbarFont = 12;
  plotFont = 12;

  subplot(4,2,3)
  field = U(Utime<time2&Utime>time1,:);
  VARlon = Ulon;
  VARtime = Utime;
  VARtime = VARtime(VARtime<time2&VARtime>time1)-t(kk);
  contourf(VARlon,VARtime,field,'LineColor','none'); hold on;
  colorbar('fontsize',colorbarFont)
  contour(VARlon,VARtime,field,[0 0],'linecolor','black','lineWidth',0.5);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfilt(OLRtime<time2&OLRtime>time1,:),[-10 -10],'linecolor','white','lineWidth',1);
  %contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfiltROSSBY(OLRtime<time2&OLRtime>time1,:),[-4 -4],'linecolor','red','lineWidth',1);
  set(gca, "fontsize", plotFont)
  title('U at 10 m (m/s)')
  ylabel('time (d)')
 

  subplot(4,2,5)
  field = SF(SFtime<time2&SFtime>time1,:);
  VARlon = SFlon;
  VARtime = SFtime;
  VARtime = VARtime(VARtime<time2&VARtime>time1)-t(kk);
  contourf(VARlon,VARtime,field,'LineColor','none'); hold on;
  colorbar('fontsize',colorbarFont)
  contour(VARlon,VARtime,field,[0.7 0.7],'linecolor','black','lineWidth',0.5);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),10+OLRfilt(OLRtime<time2&OLRtime>time1,:),[0 0],'linecolor','white','lineWidth',1);
  %contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),5.5+OLRfiltROSSBY(OLRtime<time2&OLRtime>time1,:),[0.5 0.5],'linecolor','red','lineWidth',1);
  set(gca, "fontsize", plotFont)
  title('saturation fraction (SF, [])')
  ylabel('time (d)')


  subplot(4,2,1)
  field = OLR(OLRtime<time2&OLRtime>time1,:);
  VARlon = OLRlon;
  VARtime = OLRtime;
  VARtime = VARtime(VARtime<time2&VARtime>time1)-t(kk);
  contourf(VARlon,VARtime,field,'LineColor','none'); hold on;
  colorbar('fontsize',colorbarFont)
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfilt(OLRtime<time2&OLRtime>time1,:),[-10 -10],'linecolor','white','lineWidth',1);
  %contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfiltROSSBY(OLRtime<time2&OLRtime>time1,:),[-4 -4],'linecolor','red','lineWidth',1);
  set(gca, "fontsize", plotFont)
  title(['OLR (W/m^2), day at 0: ' num2str(t(kk)) ', OLR_{min} = ' num2str(OLRstrength(kk),'%4.2f') ' W/m^2' ])
  ylabel('time (d)')

  subplot(4,2,7)
  field = dSFdt0(SFtime<time2&SFtime>time1,:);
  VARlon = SFlon;
  VARtime = SFtime;
  VARtime = VARtime(VARtime<time2&VARtime>time1)-t(kk);
  contourf(VARlon,VARtime,field,'LineColor','none'); hold on;
  colorbar('fontsize',colorbarFont)
  contour(VARlon,VARtime,field,[0 0],'linecolor','black','lineWidth',0.5);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),10+OLRfilt(OLRtime<time2&OLRtime>time1,:),[0 0],'linecolor','white','lineWidth',1);
  %contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),4+OLRfiltROSSBY(OLRtime<time2&OLRtime>time1,:),[0 0],'linecolor','red','lineWidth',1);
  set(gca, "fontsize", plotFont)
  title('dSF/dt (1/s)')
  ylabel('time (d)')
  xlabel('longitude (deg)')

  subplot(4,2,6)
  field = RFLUX(FLUXtime<time2&FLUXtime>time1,:);
  VARlon = FLUXlon;
  VARtime = FLUXtime;
  VARtime = VARtime(VARtime<time2&VARtime>time1)-t(kk);
  contourf(VARlon,VARtime,field,'LineColor','none'); hold on;
  colorbar('fontsize',colorbarFont)
  contour(VARlon,VARtime,field,[0 0],'linecolor','black','lineWidth',0.5);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfilt(OLRtime<time2&OLRtime>time1,:),[-10 -10],'linecolor','white','lineWidth',1);
  %contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfiltROSSBY(OLRtime<time2&OLRtime>time1,:),[-4 -4],'linecolor','red','lineWidth',1);
  set(gca, "fontsize", plotFont)
  title('OAFLUX latent heat flux (W/m^22)')
  ylabel('time (d)')

  subplot(4,2,8)
  field = HFLUX(FLUXtime<time2&FLUXtime>time1,:);
  VARlon = FLUXlon;
  VARtime = FLUXtime;
  VARtime = VARtime(VARtime<time2&VARtime>time1)-t(kk);
  contourf(VARlon,VARtime,field,'LineColor','none'); hold on;
  colorbar('fontsize',colorbarFont)
  contour(VARlon,VARtime,field,[0 0],'linecolor','black','lineWidth',0.5);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfilt(OLRtime<time2&OLRtime>time1,:),[-10 -10],'linecolor','white','lineWidth',1);
  %contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfiltROSSBY(OLRtime<time2&OLRtime>time1,:),[-4 -4],'linecolor','red','lineWidth',1);
  set(gca, "fontsize", plotFont)
  title('OAFLUX sentible heat flux (W/m^22)')
  ylabel('time (d)')
  xlabel('longitude (deg)')
  
%   subplot(4,2,4)
%   field = BUOYlh(BUOYtime<time2&BUOYtime>time1,:);
%   VARlon = BUOYlon;
%   VARtime = BUOYtime;
%   VARtime = VARtime(VARtime<time2&VARtime>time1)-t(kk);
%   contourf(VARlon,VARtime,field,'LineColor','none'); hold on;
%   colorbar('fontsize',colorbarFont)
%   contour(VARlon,VARtime,field,[0 0],'linecolor','black','lineWidth',0.5);
%   contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfilt(OLRtime<time2&OLRtime>time1,:),[-10 -10],'linecolor','white','lineWidth',1);
%   %contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfiltROSSBY(OLRtime<time2&OLRtime>time1,:),[-4 -4],'linecolor','red','lineWidth',1);
%   set(gca, "fontsize", plotFont)
%   title('BOUY sentible heat flux (W/m^22)')
%   ylabel('time (d)')
%   xlabel('longitude (deg)')

  
  fileName = [ 'SINGLE_' year1 '_' year2 '_' lat1 '_' lat2 '_' DATA '_VARIABLES_' num2str(t(kk)) '.png' ];
   print(fileName,'-dpng')


end

end

