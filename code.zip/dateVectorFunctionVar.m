function dateVector = dateVectorFunctionVar(year1,year2,multiplier,MODEL)

range = datenum(year2, 12, 31) - datenum (year1-1, 12, 31)-1-MODEL*5;

% DEBUG
%fileid=fopen('vecTime.asc','w');

dateVector = zeros(range,4);
years = year1:year2;
counter = 1;
for i = 1:length(years)
  year = years(i);
  Nd = 365;
  monthDays = [31 28 31 30 31 30 31 31 30 31 30 31];
  if ~MODEL
    if year==1980 || year==1984 || year==1988 || year==1992 || year==1996 || ...
       year==2000 || year==2004 || year==2008 || year==2012 || year==2016
	    Nd = 366;
      monthDays = [31 29 31 30 31 30 31 31 30 31 30 31];
    end
  end
  for k = 1:12
    for j = 1:monthDays(k)
      for m = 1:multiplier
        dateVector(counter,:) = [years(i) k j counter];
        counter = counter + 1;
      end
    end
  end
end


% DEBUG
%for j = 1:length(dateVector)
%  fprintf(fileid,'%i %.2i %.2i %4i \n', dateVector(j,1), dateVector(j,2), dateVector(j,3), dateVector(j,4))
%end
%fclose(fileid)



