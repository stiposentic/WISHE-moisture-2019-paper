function [fieldALL, OLRfiltCenter] = analyseVariable(year1, year2, multiplier, VAR, VARlon, VARtime, indexPER, subtractClimatologicalMean, CENTER, PERIOD, LOCALMEAN, RAIN, OLR1, MODEL);

dateVectorVar = dateVectorFunctionVar(year1,year2,multiplier,MODEL);
[varALL, varDJF, varMAM, varJJA, varSON] = varMonths(VAR,dateVectorVar);
varDJFmean = mean(varDJF,1);
varMAMmean = mean(varMAM,1);
varJJAmean = mean(varJJA,1);
varSONmean = mean(varSON,1);

% to calculate mean single value instead instead of a longitudinal mean
%varALLmean = mean(varALL,1);
%varALLmean = mean(varALLmean);
%varDJFmean = varDJFmean * 0 + varALLmean;
%varMAMmean = varMAMmean * 0 + varALLmean;
%varJJAmean = varJJAmean * 0 + varALLmean;
%varSONmean = varSONmean * 0 + varALLmean;


OLRfiltCenter = [];
fieldALL = zeros(80*multiplier+1,length(VARlon),size(indexPER,1));
for i = 1:size(indexPER,1)
  posLon  = indexPER(i,1);
  posTime = indexPER(i,2);
  %VARlon(1:5)'
  OLRfiltCenter = [OLRfiltCenter; [indexPER(i,3) indexPER(i,1) indexPER(i,2)]];
  for j = 1:length(VARlon)
    if posLon-0.4 < VARlon(j) && posLon+0.4 > VARlon(j)
      xLon  = j; % this is the lon  position of the MJO in the matrix
   end
  end

  if multiplier == 1 
    for j = 1:length(VARlon)
      if posLon-0.6 < VARlon(j) && posLon+0.3 > VARlon(j)
        xLon  = j; % this is the lon  position of the MJO in the matrix
     end
    end
  end % if multiplier == 1
  
  if OLR1
    for j = 1:length(VARlon)
      if posLon+0.5-0.2 < VARlon(j) && posLon+0.5+0.2 > VARlon(j)
        xLon  = j; % this is the lon  position of the MJO in the matrix
      end
      if MODEL
        if posLon < VARlon(j) && posLon > VARlon(j-1)
          xLon  = j; % this is the lon  position of the MJO in the matrix
        end
      end
    end
  end
 
  xTime = find(VARtime==posTime); % this is the time position of the MJO in the matrix

   if OLR1==1 
     if ~MODEL
       xTime = find(VARtime-0.5==posTime);
     end
   end
  %posTime
  %xTime 
  %xLon
  %whos

  if strcmp(PERIOD,'DJF'); varMean = varDJFmean; end
  if strcmp(PERIOD,'MAM'); varMean = varMAMmean; end
  if strcmp(PERIOD,'JJA'); varMean = varJJAmean; end
  if strcmp(PERIOD,'SON'); varMean = varSONmean; end
  if strcmp(PERIOD,'ALL'); varMean = varALLmean; end
 
  % calculate the mean for that period of the year, e.g. DJF will calculate 12, 1, 2 of that period
  if LOCALMEAN==1
    varMean = mean(VAR(xTime-60*multiplier:xTime+60*multiplier,:),1);
  end
% whos
%  i
%  posLon
%  posTime
%  xTime
%  size(VAR(xTime-50*multiplier:xTime+30*multiplier,:))
%  size(repmat(varMean,80*multiplier+1,1))
  % here we extract the longitudes daysLag before, and after, and at the center of MJO
  if subtractClimatologicalMean
    field = VAR(xTime-50*multiplier:xTime+30*multiplier,:) - repmat(varMean,80*multiplier+1,1) ;
  else
    field = VAR(xTime-50*multiplier:xTime+30*multiplier,:) ;
  end

  % now we push all the data to center the MJO at lon = 180
 if CENTER
  centerIndex = ceil(length(VARlon)/2);
  if centerIndex > xLon
    fieldPushed     = [field(:,xLon+centerIndex+1:end) field(:,1:xLon) field(:,xLon+1:xLon+centerIndex)];
  elseif centerIndex == xLon
    fieldPushed     = field;
  elseif centerIndex < xLon
    fieldPushed     = [field(:,xLon-centerIndex:xLon)   field(:,xLon+1:end) field(:,1:xLon-centerIndex-1)];
  end
  % here we save the regressed field in an array

  fieldALL(:,:,i) = fieldPushed;
  
 else % if CENTER

  % otherwise we can just everage the fields without pushing
  fieldALL(:,:,i) = field;

 end % if CENTER
 
  % %%%%%%%%%%%%%%% DEBUG
  % plot field and moved field to check centering
  %figure
  %plot(VARlon,centerVarPushed,'r')
  %figure
  %plot(VARlon,centerVAR,'k')
end


