function [U_PER, SF_PER, II_PER, OLR_PER, RFLUX_PER, HFLUX_PER, FLUXH_PER, FLUXV_PER, uDmrDlon_PER, vDmrDlat_PER, ...
U_M, SF_M, II_M, OLR_M, RFLUX_M, HFLUX_M, FLUXH_M, FLUXV_M, uDmrDlon_M, vDmrDlat_M] = analyseAll(year1,year2,index,CENTER,PERIOD,LOCALMEAN, U, Utime, Ulon, SF, SFtime, SFlon, II, IItime, IIlon, OLR, OLRtime, OLRlon, RFLUX, HFLUX, FLUXH, FLUXV, uDmrDlon, vDmrDlat, FLUXlon, FLUXtime, FLUXVHlon, FLUXVHtime, multiplierOLR, multiplierVARS, multiplierU, multiplierFLUX, MODEL);

dummy=0;

size(index,1)
subtractClimatologicalMean = 1;
VAR = U; VARtime = Utime; VARlon = Ulon; multiplier = multiplierU; RAIN = 0; OLR1 = 2;
[U_PER, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);
 
VAR = SF; VARtime = SFtime; VARlon = SFlon; multiplier = multiplierVARS; RAIN = 0; OLR1 = 0;
[SF_PER, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = II; VARtime = IItime; VARlon = IIlon; multiplier = multiplierVARS; RAIN = 0; OLR1 = 0;
[II_PER, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = OLR; VARtime = OLRtime; VARlon = OLRlon; multiplier = multiplierOLR; RAIN = 0; OLR1 = 1;
[OLR_PER, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = RFLUX; VARtime = FLUXtime; VARlon = FLUXlon; multiplier = multiplierFLUX; RAIN = 0; OLR1 = 0;
[RFLUX_PER, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = HFLUX; VARtime = FLUXtime; VARlon = FLUXlon; multiplier = multiplierFLUX; RAIN = 0; OLR1 = 0;
[HFLUX_PER, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = FLUXH; VARtime = FLUXVHtime; VARlon = FLUXVHlon; multiplier = multiplierVARS; RAIN = 0; OLR1 = 0;
[FLUXH_PER, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = FLUXV; VARtime = FLUXVHtime; VARlon = FLUXVHlon; multiplier = multiplierVARS; RAIN = 0; OLR1 = 0;
[FLUXV_PER, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = uDmrDlon; VARtime = FLUXVHtime; VARlon = FLUXVHlon; multiplier = multiplierVARS; RAIN = 0; OLR1 = 0;
[uDmrDlon_PER, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = vDmrDlat; VARtime = FLUXVHtime; VARlon = FLUXVHlon; multiplier = multiplierVARS; RAIN = 0; OLR1 = 0;
[vDmrDlat_PER, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);




subtractClimatologicalMean = 0;
VAR = U; VARtime = Utime; VARlon = Ulon; multiplier = multiplierU; RAIN = 0; OLR1 = 2;
[U_M, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = SF; VARtime = SFtime; VARlon = SFlon; multiplier = multiplierVARS; RAIN = 0; OLR1 = 0;
[SF_M, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = II; VARtime = IItime; VARlon = IIlon; multiplier = multiplierVARS; RAIN = 0; OLR1 = 0;
[II_M, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = OLR; VARtime = OLRtime; VARlon = OLRlon; multiplier = multiplierOLR; RAIN = 0; OLR1 = 1;
[OLR_M, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = RFLUX; VARtime = FLUXtime; VARlon = FLUXlon; multiplier = multiplierFLUX; RAIN = 0; OLR1 = 0;
[RFLUX_M, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = HFLUX; VARtime = FLUXtime; VARlon = FLUXlon; multiplier = multiplierFLUX; RAIN = 0; OLR1 = 0;
[HFLUX_M, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = FLUXH; VARtime = FLUXVHtime; VARlon = FLUXVHlon; multiplier = multiplierVARS; RAIN = 0; OLR1 = 0;
[FLUXH_M, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = FLUXV; VARtime = FLUXVHtime; VARlon = FLUXVHlon; multiplier = multiplierVARS; RAIN = 0; OLR1 = 0;
[FLUXV_M, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = uDmrDlon; VARtime = FLUXVHtime; VARlon = FLUXVHlon; multiplier = multiplierVARS; RAIN = 0; OLR1 = 0;
[uDmrDlon_M, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);

VAR = vDmrDlat; VARtime = FLUXVHtime; VARlon = FLUXVHlon; multiplier = multiplierVARS; RAIN = 0; OLR1 = 0;
[vDmrDlat_M, OLRfiltCenterPER] = analyseVariable(year1,year2,multiplier,VAR,VARlon,VARtime, index,subtractClimatologicalMean,CENTER,PERIOD,LOCALMEAN,RAIN,OLR1,MODEL);
