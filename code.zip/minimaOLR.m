function index = minimaOLR(a)

index = [];
a(a>0) = 0;

exx = 0;
limit1 = 1;
limit2 = 15;
while 1
  if limit1 > length(a)
   break
  end
  b = a(limit1:limit2,:);
  [tloc, xloc] = find(b==min(min(b)));
  tloc=tloc+limit1-1;

  if min(min(b)) >-0.1
    tloc = limit1;
  end

  if tloc==limit1 || tloc==limit2 || xloc==1 || xloc==360
    exx = 0;
  else
    index = [index; xloc tloc a(tloc,xloc) ];
  end
  limit1 = limit1 + 7;
  limit2 = limit2 + 7;
  if limit2 > length(a)
    limit2 = length(a);
  end
end
index = unique(index,'rows');

