function plotSubplot(VAR, VARlon, multiplier, cLimitL, cStep, cLimitU, YLABEL, XLABEL, TITLE, plotStd)

dx = 1/multiplier;

if plotStd == 1
  field = nanstd(VAR,3);
elseif plotStd == 0
  field = nanmean(VAR,3);
elseif plotStd == 2
  field = VAR;
end

mmm = max(max(field));
mmm = 10.5 + mmm;

lim1 = -30;
lim2 =  30;
N = size(field,1);
N1 = N - (lim2-lim1)*multiplier;
field = field(N1:N,:);
tt = lim1:dx:lim2;

contourf(VARlon-180,lim1:dx:lim2,field,'LineColor','none'); hold on;
colorbar('fontsize',12)
caxis([min(field(:)), max(field(:))]);
contour(VARlon-180,lim1:dx:lim2,field,[0 0],'linecolor','black','lineWidth',0.5);
plot([-180 180],[0 0],'w','linewidth',2); 
plot([0 0],[-50 30],'w','linewidth',2); plot([-180 180],[-36 36],'w','linewidth',2)
ylim([lim1 lim2])
ylabel(YLABEL,'fontsize',12)
xlabel(XLABEL,'fontsize',12)
xticks([-180 -120 -60 0 60 120 180])
xticklabels({'-180','-120','-60','0','60','120','180'})
title(TITLE,"interpreter","latex",'fontsize',12)