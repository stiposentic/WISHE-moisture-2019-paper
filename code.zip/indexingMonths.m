function [indexDJF, indexMAM, indexJJA, indexSON] = indexingMonths(index,dateVector);
%function [indexDJF, indexMAM, indexJJA, indexSON, indexEeNino, indexLaNina, indexNo] = indexingMonths(index,dateVector);

dayDJF = dateVector(dateVector(:,2)==12 | dateVector(:,2)==1 | dateVector(:,2)==2,4);
dayMAM = dateVector(dateVector(:,2)==3 | dateVector(:,2)==4 | dateVector(:,2)==5,4);
dayJJA = dateVector(dateVector(:,2)==6 | dateVector(:,2)==7 | dateVector(:,2)==8,4);
daySON = dateVector(dateVector(:,2)==9 | dateVector(:,2)==10 | dateVector(:,2)==11,4);
%dayElNino = dateVector(dateVector(:,2)==9 | dateVector(:,2)==10 | dateVector(:,2)==11,4);

indexDJF = [];
indexMAM = [];
indexJJA = [];
indexSON = [];
for i = 1:length(index)
  if sum(index(i,2)==dayDJF) > 0
    indexDJF =[indexDJF; index(i,:)];
  end
  if sum(index(i,2)==dayMAM) > 0
    indexMAM =[indexMAM; index(i,:)];
  end
  if sum(index(i,2)==dayJJA) > 0
    indexJJA =[indexJJA; index(i,:)];
  end
  if sum(index(i,2)==daySON) > 0
    indexSON =[indexSON; index(i,:)];
  end
end



