%-20 20 
%-15 15
%-10 10
%-5 5
%0 5
%5 0

%OLR filtOLR

% ERAI 
% U1000 U850 U200 U10 SF II
% 1991 2010
% 2000 2016

% FNL 
% U10 SF II
% 1991 2010
% 2000 2016

% MERRA2
% U10 SF II
% 1991 2010
% 2000 2016



% MODELS:
% CNRM good MJO model
% NAVGEM bad MJO model
% U1000 SF II
% 1991 2010

RELOAD = 1;

if RELOAD

clear all;
close all;
%pkg load netcdf



%DATA = 'CNRM'; FNL=0; MERRA=0; MODEL='CNRM_'; MODELS =1;
%multiplierOLR = 1; multiplierVARS = 1; 
%Ulabel = 'U1000'; UlabelVar = 'U1000'; multiplierU = 1;
%year1 = '1991'; year1n = 1991;
%year2 = '2010'; year2n = 2010;

%DATA = 'NAVGEM'; FNL=0; MERRA=0; MODEL='NAVGEM_'; MODELS =1;
%multiplierOLR = 1; multiplierVARS = 1;
%Ulabel = 'U1000'; UlabelVar = 'U1000'; multiplierU = 1;
%year1 = '1991'; year1n = 1991;
%year2 = '2010'; year2n = 2010;


%DATA = 'ERAI'; FNL=0; MERRA=0; MODEL=''; MODELS=0; filteredOLRlabel = 'k1_5_';
%multiplierOLR = 1; multiplierVARS = 2; 
%Ulabel = 'U10'; UlabelVar = 'u10'; multiplierU = 2;
%%Ulabel = 'U200'; UlabelVar = 'U200'; multiplierU = 4;
%year1 = '1986'; year1n = 1986;
%year2 = '2018'; year2n = 2018;

DATA = 'FNL'; FNL=1; MERRA=0; MODEL=''; MODELS=0; filteredOLRlabel = 'k1_5_';
multiplierOLR = 1; multiplierVARS = 4;
Ulabel = 'U10'; UlabelVar = 'U10'; multiplierU = 4;
year1 = '2000'; year1n = 2000;
year2 = '2016'; year2n = 2016;

%DATA = 'MERRA2'; FNL=0; MERRA = 1; MODEL=''; MODELS=0;
%multiplierOLR = 1; multiplierVARS = 4;
%Ulabel = 'U10'; UlabelVar = 'U10'; multiplierU = 4;
%year1 = '2000'; year1n = 2000;
%year2 = '2016'; year2n = 2016;




%FILESPATH = '/data.qt3/ssentic/EASTERLY_DATA/';
FILESPATH = '';
EXCLUDE = 0; EXCLUDE_WEAKER = 0; OLRcutoff = 0; % ALL data, no Exclusions
EXCLUDE = 1; EXCLUDE_WEAKER = 1; OLRcutoff = -12; % exclude weaker MJOs
%EXCLUDE = 1; EXCLUDE_WEAKER = 0; OLRcutoff = -13; % exclude stronger MJOs
EXTRA_EXCLUDE_LABEL = [ 'EX' num2str(EXCLUDE) '.' num2str(EXCLUDE_WEAKER) '.' num2str(abs(OLRcutoff)) ];
% include only MJOs with maxima between LON1 and LON2
%LON1 = 50; LON2 = 200;
%LON1 = 50; LON2 = 100;
%LON1 = 100; LON2 = 150;
%LON1 = 150; LON2 = 200;
LON1 = 0; LON2 = 360;
%LON1 = 30; LON2 = 250;
%LON1 = 30; LON2 = 140;
%LON1 = 140; LON2 = 250;
LON_EXCLUDE_LABEL = [ 'LON' num2str(LON1,'%03i') '_' num2str(LON2,'%03i') ];
% choice: 5 10 15 20 symetric around the equator, or -5 to 0 and 0 to 5
lat1 = '-10';
lat2 = '10';
%lat1 = '0';
%lat2 = '5';


range = datenum(str2num(year2), 12, 31) - datenum(str2num(year1)-1, 12, 31)-1;
dateVector = dateVectorFunction(str2num(year1),str2num(year2),MODELS);

%	OLR, time in days from start year
OLR     = ncread([FILESPATH 'OLR_' MODEL year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'olr');
OLR(OLR>1000) = NaN; % exclude missing data ( a few periods are missing
OLRlon  = ncread([FILESPATH 'OLR_' MODEL year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');      % from 0.5 deg to 359.5 deg
OLRtime = ncread([FILESPATH 'OLR_' MODEL year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');     % counting from day 1 of start year
OLRfilt = ncread([FILESPATH 'FiltOLR_MJO_' filteredOLRlabel MODEL year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'filtdata');
filteredOLRlabel = '';
%OLRfilt = [OLRfilt; OLRfilt(end,:)];
%OLRfiltROSSBY = ncread([FILESPATH 'FiltOLR_ROSSBY_' filteredOLRlabel MODEL year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'filtdata');
% get sf, ii
II     = ncread([FILESPATH DATA '_VARS_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'sf'); % !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! sf instead of II!!!!!
IItime = ncread([FILESPATH DATA '_VARS_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');
IIlon  = ncread([FILESPATH DATA '_VARS_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');

EXTRALABEL = '';
SF     = ncread([FILESPATH DATA '_VARS_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'sf');
SFtime = ncread([FILESPATH DATA '_VARS_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');
SFlon  = ncread([FILESPATH DATA '_VARS_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');

%EXTRALABEL = 'mr_BL1km_latAve10';
%SF     = ncread('ERAI_Q1km_1986_2018.nc','mr1km10')';
%SFtime = ncread('ERAI_Q1km_1986_2018.nc','time');
%SFlon  = ncread('ERAI_Q1km_1986_2018.nc','lon');

%EXTRALABEL = 'sf_latAve10';
%SF     = ncread('ERAI_Qall_1986_2018.nc','sf10')';
%SFtime = ncread('ERAI_Qall_1986_2018.nc','time');
%SFlon  = ncread('ERAI_Qall_1986_2018.nc','lon');



% get zonal Wind
U     = ncread([FILESPATH DATA '_' Ulabel '_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],UlabelVar);
Ulon  = ncread([FILESPATH DATA '_' Ulabel '_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');
Utime = ncread([FILESPATH DATA '_' Ulabel '_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');
% get surface fluxes
%RFLUX = ncread([FILESPATH DATA '_FLUXES_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'rflux');
%HFLUX = ncread([FILESPATH DATA '_FLUXES_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'hflux');
%FLUXlon = ncread([FILESPATH DATA '_FLUXES_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');
%FLUXtime = ncread([FILESPATH DATA '_FLUXES_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');

multiplierFLUX = 1;
RFLUX = ncread([FILESPATH 'lh_oaflux_' year1 '_' year2 '.nc'],'lhtfl');
HFLUX = ncread([FILESPATH 'sh_oaflux_' year1 '_' year2 '.nc'],'shtfl')';
FLUXlon = ncread([FILESPATH 'lh_oaflux_' year1 '_' year2 '.nc'],'lon');
FLUXtime = ncread([FILESPATH 'lh_oaflux_' year1 '_' year2 '.nc'],'time');

%horiz and vert fluxes
convert = (-100/9.81)*86400 *3.45/100;
% FLUXH = convert * ncread([FILESPATH DATA '_FLUXVH_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'horizAdv')';
% FLUXV = (convert/100) * ncread([FILESPATH DATA '_FLUXVH_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'vertAdv')';
% uDmrDlon = convert * ncread([FILESPATH DATA '_FLUXVH_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'uDmrDlon')';
% vDmrDlat = convert * ncread([FILESPATH DATA '_FLUXVH_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'vDmrDlat')';
% FLUXVHlon = ncread([FILESPATH DATA '_FLUXVH_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'lon');
% FLUXVHtime = ncread([FILESPATH DATA '_FLUXVH_' year1 '_' year2 '_' lat1 '_' lat2 '.nc'],'time');

BUOYlh     = ncread('TOATRION1986_2018.nc','lh');
BUOYlon    = ncread('TOATRION1986_2018.nc','lon')';
BUOYtime   = ncread('TOATRION1986_2018.nc','time')';
BUOYlh(BUOYlh > 100000) = NaN;
BUOYlh(1:4000,:) = NaN;

FLUXH = SF;
FLUXV = SF;
uDmrDlon = SF;
vDmrDlat = SF;
FLUXVHlon = SFlon;
FLUXVHtime = SFtime;



RFLUX(RFLUX > 100000) = NaN;
HFLUX(HFLUX > 100000) = NaN;

if FNL
  U = [U; U(end,:); U(end,:) ];
  Utime = [Utime; Utime(end)+Utime(end)-Utime(end-1); Utime(end)+2*(Utime(end)-Utime(end-1)) ];
  U = U(1:2:end,:);
  Utime = Utime(1:2:end);
  multiplierU = 2;

  SF = SF(1:2:end,:);
  SFtime = SFtime(1:2:end);
  II = II(1:2:end,:);
  IItime = IItime(1:2:end);
  %HFLUX = [HFLUX(1:2:end,:); HFLUX(end,:)];
  %RFLUX = [RFLUX(1:2:end,:); RFLUX(end,:)];
  %FLUXtime = [FLUXtime(1:2:end); FLUXtime(end)+FLUXtime(end)-FLUXtime(end-1)];
  %HFLUX = [HFLUX(1:2:end,:)];
  %RFLUX = [RFLUX(1:2:end,:)];
  %FLUXtime = [FLUXtime(1:2:end)];
  multiplierVARS = 2;
end
if MERRA
  U = U(1:6:end,:);
  Utime = Utime(1:6:end);
  U = [U; U(end,:); U(end,:); U(end,:); U(end,:) ];
  Utime = [Utime; Utime(end)+Utime(end)-Utime(end-1); Utime(end)+2*(Utime(end)-Utime(end-1)); ...
           Utime(end)+3*(Utime(end)-Utime(end-1)); Utime(end)+4*(Utime(end)-Utime(end-1)) ];
  Utime = Utime - 3287.0;
end

SMOOTHVARIABLES = 1; SMOOTHWINDOW = 2;
if SMOOTHVARIABLES
  OLR   = smooth2a(double(OLR),SMOOTHWINDOW*multiplierOLR ,2); % last number decides that the smoothing will be over 5 degrees
  SF    = smooth2a(double(SF ),SMOOTHWINDOW*multiplierVARS,3);
  II    = smooth2a(double(II ),SMOOTHWINDOW*multiplierVARS,3);
  HFLUX = smooth2a(double(HFLUX),SMOOTHWINDOW*multiplierVARS,2);
  RFLUX = smooth2a(double(RFLUX),SMOOTHWINDOW*multiplierVARS,2);
  U     = smooth2a(double(U  ),SMOOTHWINDOW*multiplierU,   2);
  FLUXH = smooth2a(double(FLUXH),SMOOTHWINDOW*multiplierVARS,   2);
  FLUXV = smooth2a(double(FLUXV),SMOOTHWINDOW*multiplierVARS,   2);
  uDmrDlon = smooth2a(double(uDmrDlon),SMOOTHWINDOW*multiplierVARS,   2);
  vDmrDlat = smooth2a(double(vDmrDlat),SMOOTHWINDOW*multiplierVARS,   2);
end
dSFdt = (SF(3:end,:)-SF(1:end-2,:))/(1/multiplierVARS);
dSFdt = [dSFdt(1,:); dSFdt; dSFdt(end,:)];

dSFdt  = smooth2a(double(dSFdt ),SMOOTHWINDOW*multiplierVARS,3);

% this if statement is used for extracting the 0 to 5N DYNAMO data
% used with commenting out line with OLRfilt above
if 0
t = 4347;
lonRange = Ulon<80 & Ulon>70;
% second DYNAMO case
field = U((t-30)*multiplierU:(t+30)*multiplierU,lonRange);
Utime = -30:1/multiplierU:30;
U2 = mean(field,2);
% first DYNAMO case
field = U((t-30-28)*multiplierU:(t+30-28)*multiplierU,lonRange);
U1 = mean(field,2);
save -mat7-binary plot5_DYNAMO2_0_5_70_80.mat U1 Utime U2
stop
end


if 1
% get positions of minima of filtered OLR
index = minimaOLR(OLRfilt);
index = index(index(:,1)>LON1 & index(:,1)<=LON2, :);
%index = index(index(:,3)>-13, :); % use only MJOs with OLR greater than -10 W/ms (the weaker ones)
%index = index(index(:,3)<-13, :); % use only MJOs with OLR less than -10 W/ms (the STRONGER ones)


% remove MJOs within last 30 days or first 50 days,
% they mess up the averaging process, but we assume
% one or two MJOs don't make a difference in the 
% final result
index(index(:,2)<51,:) = [];
index(index(:,2)>length(OLRtime)*multiplierOLR-31,:) = [];
%if we want to EXCLUDE a portion of the data
if EXCLUDE
  if EXCLUDE_WEAKER
    index = index(index(:,3)<OLRcutoff,:);
  else
    index = index(index(:,3)>=OLRcutoff,:);
  end
end

% FILTERING the selected OLR minima
if 0
% Use only warm pool data 
index = index(index(:,1)>0 & index(:,1)<200, :);
%length(index) % brings from 190 identified to 177
% Exclude successive MJOs, i.e. find MJOs which don't have a MJO in the 30 days preceding it
indexTMP = [];
for i = 1:length(index)
  timeIND = index(i,2);
  if sum(index(:,2) > timeIND-40 & index(:,2)< timeIND) == 0
    indexTMP = [indexTMP; index(i,:) ];
  end
end
length(indexTMP)
index=indexTMP;
FILTERindexLABEL = 'warmPoolAndExlude40dayPrevious';
%stop
end
FILTERindexLABEL = 'noExclusions';


if 0
% plot the histogram of OLR strengths
figure
  subplot(1,2,1)
hist(index(:,3),-38:2:0,'facecolor','none')
ylabel('N','fontsize',12)
xlabel('OLR minimum (W/m^2)','fontsize',12)
xlim([-38 0])
set(gca,'fontsize',12)
  subplot(1,2,2)
hist(index(:,1),0:10:360,'facecolor','none')
ylabel('N','fontsize',12)
xlabel('longitude position (deg)','fontsize',12)
xlim([0 360])
set(gca,'fontsize',12)
%print('PRODUCTIONcountStrength.eps','-S400,300','-depsc')
%length(index)
%sum(index(:,3)<-17)
%stop
end
end % if 0

















% OLR versus mean(U) 10 days before
if 0

correlations = [];
for t1 = -20:-1
  t2=t1+1;
  data = [];
  for i = 1:size(index,1)
    posLon  = index(i,1);
    t = index(i,2);
    field = mean(mean(U((t+t1)*multiplierU:(t+t2)*multiplierU,:)));
    if index(i,3) > -35
      data = [ data; index(i,3) field ];
    end
  end
  x = data(:,1);
  y = data(:,2);
  if t1 == -10
    figure('rend','painters','pos',[10 10 350 450])
    X = [ones(length(x),1) x];
    b = X\y;
    yCalc2 = X*b;
    subplot(2,1,2)
    plot(x,y,'k.','markerSize',13);hold on;
    plot(x,yCalc2,'k','linewidth',2)
    %legend('Data','Linear Fit','Location','best')
    xlabel('filtered OLR minimum amplitude (W m^{-2})')
    ylabel('<U> (m s^{})')
 %   title('t = -6 d, R = 0.52')
    corr(x,y)
  end
  R = corr(x,y);
  correlations = [ correlations; R ];
end
subplot(2,1,1)
plot(-20:-1,correlations,'k','linewidth',2);hold on;
xlabel('time (days before OLR minimum)')
ylabel('R')



correlations = [];
for t1 = -20:-1
  t2=t1+1;
  data = [];
  for i = 1:size(index,1)
    posLon  = index(i,1);
    t = index(i,2);
    field = mean(mean(U((t+t1)*multiplierU:(t+t2)*multiplierU,:)));
    if index(i,3) < -15 & index(i,3) > -35
      data = [ data; index(i,3) field ];
    end
  end
  x = data(:,1);
  y = data(:,2);
  if t1 == -10
    X = [ones(length(x),1) x];
    b = X\y;
    yCalc2 = X*b;
    subplot(2,1,2)
    plot(x,y,'r.','markerSize',13);hold on;
    plot(x,yCalc2,'r','linewidth',2)
    %legend('Data','Linear Fit','Location','best')
    xlabel('filtered OLR minimum amplitude (W m^{-2})')
    ylabel('<U> (m s^{})')
    title('R = 0.34, \color{red}R = 0.52')
    
    corr(x,y)
  end
  R = corr(x,y);
  correlations = [ correlations; R ];
end
subplot(2,1,1)
plot(-20:-1,correlations,'r','linewidth',2);hold on;
    plot([-10 -10],[0.2 0.6],'k','linewidth',1)
xlabel('time (days before OLR minimum)')
ylabel('R')
legend('OLR < 0','OLR< -15') %,'Location','northoutside')




stop
end







%hist(index,-30:0)
%length(index)
%length(index(index(:,3)<-18,:))
%stop

% for plotting average of zonal wind 
if 0
dateVectorVar = dateVectorFunctionVar(year1n,year2n,multiplierU,0);
[yearMean, yearDJF, yearMAM, yearJJA, yearSON] = varYearly(year1n, year2n, U, dateVectorVar, multiplierU);
mean1 = movingmean(mean(yearMean,2),20,1,[]);
meanS = movingmean(std(yearMean,0,2),20,1,[]);
meanM = movingmean(std(yearMean,0,2),20,1,[]);
time1 = 1/multiplierU:1/multiplierU:365;
save('-mat',['zonalWindYearlyAverage_' year1 '_' year2 '_' lat1 '_' lat2 '_' DATA '.mat'],'mean1','meanS','meanM','time1');
stop
end

















% N of MJOs
numMJOs = length(index)
indexORIG = index;
% divide indexed data into months, DJF is December, January, and February, etc.
[indexDJF, indexMAM, indexJJA, indexSON] = indexingMonths(index,dateVector);

CENTER = 1; 
LOCALMEAN = 0;
PERIOD = 'DJF'; index = indexDJF;
[U_D, SF_D, II_D, OLR_D, ...
RFLUX_D, HFLUX_D, FLUXH_D, FLUXV_D, uDmrDlon_D, vDmrDlat_D, ...
U_D_M, SF_D_M, II_D_M, OLR_D_M, ...
RFLUX_D_M, HFLUX_D_M, FLUXH_D_M, FLUXV_D_M, uDmrDlon_D_M, vDmrDlat_D_M] = ...
analyseAll(year1n,year2n,index,CENTER,PERIOD,LOCALMEAN, U, Utime, Ulon, SF, SFtime, SFlon, II, IItime, ...
IIlon, OLR, OLRtime, OLRlon, RFLUX, HFLUX, FLUXH, FLUXV, uDmrDlon, vDmrDlat, FLUXlon, FLUXtime, FLUXVHlon, FLUXVHtime, ...
multiplierOLR, multiplierVARS, multiplierU, multiplierFLUX, MODELS);

PERIOD = 'MAM'; index = indexMAM;
[U_M, SF_M, II_M, OLR_M, ...
RFLUX_M, HFLUX_M, FLUXH_M, FLUXV_M, uDmrDlon_M, vDmrDlat_M, ...
U_M_M, SF_M_M, II_M_M, OLR_M_M, ...
RFLUX_M_M, HFLUX_M_M, FLUXH_M_M, FLUXV_M_M, uDmrDlon_M_M, vDmrDlat_M_M] = ...
analyseAll(year1n,year2n,index,CENTER,PERIOD,LOCALMEAN, U, Utime, Ulon, SF, SFtime, SFlon, II, IItime, ...
IIlon, OLR, OLRtime, OLRlon, RFLUX, HFLUX, FLUXH, FLUXV, uDmrDlon, vDmrDlat, FLUXlon, FLUXtime, FLUXVHlon, FLUXVHtime, ...
multiplierOLR, multiplierVARS, multiplierU, multiplierFLUX, MODELS);

PERIOD = 'JJA'; index = indexJJA;
[U_J, SF_J, II_J, OLR_J, ...
RFLUX_J, HFLUX_J, FLUXH_J, FLUXV_J, uDmrDlon_J, vDmrDlat_J, ...
U_J_M, SF_J_M, II_J_M, OLR_J_M, ...
RFLUX_J_M, HFLUX_J_M, FLUXH_J_M, FLUXV_J_M, uDmrDlon_J_M, vDmrDlat_J_M] = ...
analyseAll(year1n,year2n,index,CENTER,PERIOD,LOCALMEAN, U, Utime, Ulon, SF, SFtime, SFlon, II, IItime, ...
IIlon, OLR, OLRtime, OLRlon, RFLUX, HFLUX, FLUXH, FLUXV, uDmrDlon, vDmrDlat, FLUXlon, FLUXtime, FLUXVHlon, FLUXVHtime,  ...
multiplierOLR, multiplierVARS, multiplierU, multiplierFLUX, MODELS);

PERIOD = 'SON'; index = indexSON;
[U_S, SF_S, II_S, OLR_S, ...
RFLUX_S, HFLUX_S, FLUXH_S, FLUXV_S, uDmrDlon_S, vDmrDlat_S, ...
U_S_M, SF_S_M, II_S_M, OLR_S_M, ...
RFLUX_S_M, HFLUX_S_M, FLUXH_S_M, FLUXV_S_M, uDmrDlon_S_M, vDmrDlat_S_M] = ...
analyseAll(year1n,year2n,index,CENTER,PERIOD,LOCALMEAN, U, Utime, Ulon, SF, SFtime, SFlon, II, IItime, ...
IIlon, OLR, OLRtime, OLRlon, RFLUX, HFLUX, FLUXH, FLUXV, uDmrDlon, vDmrDlat, FLUXlon, FLUXtime, FLUXVHlon, FLUXVHtime, ...
multiplierOLR, multiplierVARS, multiplierU, multiplierFLUX, MODELS);

index = indexORIG;


% for fields where the climatology WAS removed!
ALL_Up    = concatField(size(U_D,1),size(U_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), U_D, U_M, U_J, U_S);
ALL_SFp   = concatField(size(SF_D,1),size(SF_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), SF_D, SF_M, SF_J, SF_S);
ALL_IIp   = concatField(size(II_D,1),size(II_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), II_D, II_M, II_J, II_S);
ALL_OLRp  = concatField(size(OLR_D,1),size(OLR_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), OLR_D, OLR_M, OLR_J, OLR_S);
ALL_RFLUXp  = concatField(size(RFLUX_D,1),size(RFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), RFLUX_D, RFLUX_M, RFLUX_J, RFLUX_S);
ALL_HFLUXp  = concatField(size(HFLUX_D,1),size(HFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), HFLUX_D, HFLUX_M, HFLUX_J, HFLUX_S);

% ALL_FLUXHp  = concatField(size(FLUXH_D,1),size(RFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA), FLUXH_D, FLUXH_M, FLUXH_J, FLUXH_S);
% ALL_FLUXVp  = concatField(size(FLUXV_D,1),size(HFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA), FLUXV_D, FLUXV_M, FLUXV_J, FLUXV_S);
% ALL_uDmrDlonP  = concatField(size(uDmrDlon_D,1),size(RFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA), uDmrDlon_D, uDmrDlon_M, uDmrDlon_J, uDmrDlon_S);
% ALL_vDmrDlatP  = concatField(size(vDmrDlat_D,1),size(HFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA), vDmrDlat_D, vDmrDlat_M, vDmrDlat_J, vDmrDlat_S);

% SF, take partial time derivative
dSFdtp = (ALL_SFp(3:end,:,:)-ALL_SFp(1:end-2,:,:))/(1/multiplierVARS);
% II, take partial time derivative
dIIdtp = (ALL_IIp(3:end,:,:)-ALL_IIp(1:end-2,:,:))/(1/multiplierVARS);

% for fields where the climatology was not removed!
ALL_U    = concatField(size(U_D,1),size(U_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), U_D_M, U_M_M, U_J_M, U_S_M);
ALL_SF   = concatField(size(SF_D,1),size(SF_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), SF_D_M, SF_M_M, SF_J_M, SF_S_M);
ALL_II   = concatField(size(II_D,1),size(II_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), II_D_M, II_M_M, II_J_M, II_S_M);
ALL_OLR  = concatField(size(OLR_D,1),size(OLR_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), OLR_D_M, OLR_M_M, OLR_J_M, OLR_S_M);
ALL_RFLUX  = concatField(size(RFLUX_D,1),size(RFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), RFLUX_D_M, RFLUX_M_M, RFLUX_J_M, RFLUX_S_M);
ALL_HFLUX  = concatField(size(HFLUX_D,1),size(HFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), HFLUX_D_M, HFLUX_M_M, HFLUX_J_M, HFLUX_S_M);

% ALL_FLUXH  = concatField(size(FLUXH_D,1),size(RFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), FLUXH_D_M, FLUXH_M_M, FLUXH_J_M, FLUXH_S_M);
% ALL_FLUXV  = concatField(size(FLUXV_D,1),size(HFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), FLUXV_D, FLUXV_M_M, FLUXV_J_M, FLUXV_S_M);
% ALL_uDmrDlon  = concatField(size(uDmrDlon_D,1),size(RFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), uDmrDlon_D_M, uDmrDlon_M_M, uDmrDlon_J_M, uDmrDlon_S_M);
% ALL_vDmrDlat  = concatField(size(vDmrDlat_D,1),size(HFLUX_D,2),size(index,1),size(indexDJF,1), size(indexMAM,1), size(indexJJA,1), vDmrDlat_D_M, vDmrDlat_M_M, vDmrDlat_J_M, vDmrDlat_S_M);


dSFdt0 = dSFdt;
% smooth SF and take partial time derivative 
dSFdt = (ALL_SF(3:end,:,:)-ALL_SF(1:end-2,:,:))/(1/multiplierVARS);
% smooth II and take partial time derivative 
dIIdt = (ALL_II(3:end,:,:)-ALL_II(1:end-2,:,:))/(1/multiplierVARS);


[Hup,Pup] = statTestFunct(ALL_Up);
[Hsfp,Psfp] = statTestFunct(ALL_SFp);
[Hdsfdtp,Pdsfdtp] = statTestFunct(dSFdt);
[Hrfluxp,Prfluxp] = statTestFunct(ALL_RFLUXp);
[Hhfluxp,Phfluxp] = statTestFunct(ALL_HFLUXp);

%[Hu,Pu] = statTestFunctFULL(ALL_U,U);
%[Hsf,Psf] = statTestFunctFULL(ALL_SF,SF);
%[Hrflux,Prflux] = statTestFunctFULL(ALL_RFLUX,RFLUX);
%[Hhflux,Phflux] = statTestFunctFULL(ALL_HFLUX,HFLUX);


end % RELOAD if statement



% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Until here processing files and analysis


%close all;

% [Hup,Pup] = statTestFunct(ALL_Up);
% [Hsfp,Psfp] = statTestFunct(ALL_SFp);
% [Hdsfdtp,Pdsfdtp] = statTestFunct(dSFdt);
% [Hrfluxp,Prfluxp] = statTestFunct(ALL_RFLUXp);
% [Hhfluxp,Phfluxp] = statTestFunct(ALL_HFLUXp);


% pp = 0.05;
% 
% Hup = Pup   > pp;
% Hsfp = Psfp > pp;
% Hdsfdtp = Pdsfdtp > pp;
% Hrfluxp = Prfluxp > pp;
% Hhfluxp = Phfluxp > pp;


















plotStd = 0; 

if 1

figure('rend','painters','pos',[10 10 500 800])
  subplot(4,1,1); plotSubplotStat(ALL_Up, Ulon, multiplierU, -2, .5, 2, 'time (d)', '', 'a) zonal wind pert. $\mathrm{(m\ s^{-1})}$',plotStd,Hup);
  subplot(4,1,2); plotSubplotStat(ALL_SFp, SFlon, multiplierVARS, -2, .5, 2, 'time (d)', '','b) saturation fraction pert.',plotStd,Hsfp);
  subplot(4,1,4); plotSubplotStat(ALL_RFLUXp, FLUXlon, multiplierFLUX, -2, .5, 2, 'time (d)', 'longitude (deg)','d) OAFlux surface latent heat flux pert. $\mathrm{(W\ m^{-2})}$',plotStd,Hrfluxp);
  %subplot(5,1,4); plotSubplotStat(ALL_HFLUXp, FLUXlon, multiplierFLUX, -2, .5, 2, 'time (d)', 'longitude (deg)','d) OAFlux surface sensible heat flux pert. $\mathrm{(W\ m^{-2})}$',plotStd,Hhfluxp);
  subplot(4,1,3); plotSubplotDeriv(dSFdt, SFlon, multiplierVARS, 0,0,0, 'time (d)', '', ...
                                       'c) saturation fraction tendency, $\mathrm{\partial SF/\partial t\ (1\ d^{-1})}$',Hdsfdtp);
print(['REVIEW_PRODUCTION_figure4_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.png'],'-dpng')
print(['REVIEW_PRODUCTION_figure4_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL '.eps'],'-depsc')


% figure('rend','painters','pos',[10 10 500 900])
%    subplot(5,1,1); plotSubplot(ALL_U, Ulon, multiplierU, -2, .5, 2, 'time (d)', '', 'a) zonal wind $\mathrm{(m\ s^{-1})}$',plotStd);
%    subplot(5,1,2); plotSubplot(ALL_SF, SFlon, multiplierVARS,-2,.5, 2, 'time (day)', '', 'b) saturation fraction ',plotStd);
%    subplot(5,1,3); plotSubplot(ALL_RFLUX, FLUXlon, multiplierFLUX,-2,.5, 2, 'time (d)', '', 'c) OAFlux latent heat flux $\mathrm{(W\ m^{-2})}$ ',plotStd);
%    subplot(5,1,4); plotSubplot(ALL_HFLUX, FLUXlon, multiplierFLUX,-2,.5, 2, 'time (d)', '', 'd) OAFlux sensible heat flux $\mathrm{(W\ m^{-2})}$ ',plotStd);
%    subplot(5,1,5); plotSubplotDeriv(dSFdt, SFlon, multiplierVARS, 0,0,0, 'time (d)', 'longitude lag (deg)', ...
%                                         'e) saturation fraction tendency, $\mathrm{\partial SF/\partial t\ (1\ d^{-1})}$',Hdsfdtp);
% print(['REVIEW_PRODUCTION_figure3_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL '_' EXTRALABEL '.png'],'-dpng')
% %print(['REVIEW_PRODUCTION_figure3_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL '.eps'],'-depsc')

%figure('rend','painters','pos',[10 10 500 900])
%  subplot(5,1,1); plotSubplotStat(ALL_U, Ulon, multiplierU, -2, .5, 2, 'time (d)', '', 'a) zonal wind $\mathrm{(m\ s^{-1})}$',plotStd,Hu);
%  subplot(5,1,2); plotSubplotStat(ALL_SF, SFlon, multiplierVARS,-2,.5, 2, 'time (day)', '', 'b) saturation fraction ',plotStd,Hsf);
%  subplot(5,1,3); plotSubplotStat(ALL_RFLUX, FLUXlon, multiplierFLUX,-2,.5, 2, 'time (d)', '', 'c) OAFlux latent heat flux $\mathrm{(W\ m^{-2})}$ ',plotStd,Hrflux);
%  subplot(5,1,4); plotSubplotStat(ALL_HFLUX, FLUXlon, multiplierFLUX,-2,.5, 2, 'time (d)', '', 'd) OAFlux sensible heat flux $\mathrm{(W\ m^{-2})}$ ',plotStd,Hhflux);
%  subplot(5,1,5); plotSubplotDeriv(dSFdt, SFlon, multiplierVARS, 0,0,0, 'time (d)', 'longitude lag (deg)', ...
%                                       'e) saturation fraction tendency, $\mathrm{\partial SF/\partial t\ (1\ d^{-1})}$',Hdsfdtp);
%print(['REVIEW_PRODUCTION_figure3_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL '_' EXTRALABEL '.png'],'-dpng')
%print(['REVIEW_PRODUCTION_figure3_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL '_' EXTRALABEL '.eps'],'-depsc')

end %if


% Hup(Hup==1) = NaN;          
% Hsfp(Hsfp==1) = NaN;        
% Hdsfdtp(Hdsfdtp==1) = NaN;  
% Hrfluxp(Hrfluxp==1) = NaN;  
% Hhfluxp(Hhfluxp==1) = NaN;  
% 
% Hup(Hup==0) = 1;          
% Hsfp(Hsfp==0) = 1;        
% Hdsfdtp(Hdsfdtp==0) = 1;  
% Hrfluxp(Hrfluxp==0) = 1;  
% Hhfluxp(Hhfluxp==0) = 1;  


% plot single intersection
if 1

load fuchsModelFieldsV7.mat;
figure('rend','painters','pos',[10 10 450 350])
subplot(2,1,1)
uu = mean(ALL_Up,3); uu = uu(100,:);
sf = mean(ALL_SFp,3); sf = sf(100,:);
dsf = mean(dSFdtp,3); dsf = dsf(99,:);
mrflux = nanmean(ALL_RFLUXp,3); mrflux = mrflux(50,:);
hflux = nanmean(ALL_HFLUXp,3); hflux = hflux(50,:);
plot(Ulon-180,uu/max(uu),'r','lineWidth',2); hold on;
plot(SFlon-180,sf/max(sf),'b','lineWidth',2)
plot(SFlon-180,dsf/abs(min(dsf)),'k','lineWidth',2)
plot(FLUXlon-180,mrflux/max(abs(mrflux)),'m','lineWidth',2); hold on;
%plot(FLUXlon-180,hflux/max(abs(hflux)),'g','lineWidth',2); hold on;
plot(SFlon-180,0*dsf/abs(min(dsf)),'k','lineWidth',1)
plot([0 0],[-1.1 1.5],'k--','LineWidth',1)
%h = legend('\DeltaU','\DeltaSF','\partialSF/\partialt','l.h. flux','s.h. flux');
h = legend('\DeltaU','\DeltaSF','\partialSF/\partialt','l.h. flux');
set(h,'position',[0.80 .92 0.15 0.0],'fontsize', 8)
ylabel('', 'fontsize', 12)
xlabel('longitude lag (deg)','fontsize', 12)
%title('perturbations from FNL reanalysis', 'fontsize', 12)
xlim([-180 180])
ylim([-1.1 1.5])
text(-167,1.12,'a)', 'fontsize',11)
set(gca, 'fontsize', 12)

subplot(2,1,2)
plot(x-pi,ur/max(ur),'r','lineWidth',2); hold on;
plot(x-pi,qr/abs(min(qr)),'b','lineWidth',2)
plot(x-pi,dqdtr/max(dqdtr),'k','lineWidth',2)
plot(x-pi,-ur/max(ur),'m','lineWidth',2)
plot(x-pi,ur*0,'k')
plot([0 0],[-1.1 1.5],'k--','LineWidth',1)
h = legend('\DeltaU','\Deltaq','\partialq/\partialt','l.h. flux');
set(h,'position',[0.80 .485 0.15 0.0],'fontsize', 8)
ylabel('', 'fontsize', 12)
xlabel('non-dimensional longitude lag', 'fontsize', 12)
%title('perturbations from Fuchs and Raymond (2017)', 'fontsize', 12)
set(gca,'fontsize',12)
xlim([-pi pi])
ylim([-1.1 1.5])
text(-2.9,1.12,'b)', 'fontsize',11)

 print(['REVIEW_PRODUCTION_figure6_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.eps'],'-depsc')
 print(['REVIEW_PRODUCTION_figure6_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.png'],'-dpng')



% Upert = nanmean(ALL_Up,3);
% Up = Upert(:,180);
% SFpert = nanmean(ALL_SFp,3);
% SFp = SFpert(:,180);
% dSFdtpert = nanmean(dSFdtp,3);
% RFLUXp = nanmean(ALL_RFLUXp,3);
% dSdtp = dSFdtpert(:,180);
% timeP = -50:1/multiplierU:30;



% Upert = nanmean(ALL_Up,3).*Hup;
% Up = Upert(:,180);
% SFpert = nanmean(ALL_SFp,3).*Hsfp;
% SFp = SFpert(:,180);
% dSFdtpert = nanmean(dSFdtp,3).*Hdsfdtp;
% RFLUXp = nanmean(ALL_RFLUXp,3).*Hrfluxp;
% HFLUXp = nanmean(ALL_HFLUXp,3).*Hhfluxp;
% dSFdtp = dSFdtpert(:,180);
% timeP = -50:1/multiplierU:30;
% RFLUXp = RFLUXp(:,180);
% HFLUXp = HFLUXp(:,180);
% timePflux = timeP(1:2:end);

Upert1 = nanmean(ALL_Up,3);
Up1 = Upert1(:,length(Ulon)/2);
SFpert1 = nanmean(ALL_SFp,3);
SFp1 = SFpert1(:,length(SFlon)/2);
dSFdtpert1 = nanmean(dSFdtp,3);
RFLUXp1 = nanmean(ALL_RFLUXp,3);
HFLUXp1 = nanmean(ALL_HFLUXp,3);
dSFdtp1 = dSFdtpert1(:,length(SFlon)/2);
timeP = -50:1/multiplierU:30;
RFLUXp1 = RFLUXp1(:,length(FLUXlon)/2);
HFLUXp1 = HFLUXp1(:,length(FLUXlon)/2);
timePflux = timeP(1:2:end);

if 0
    
save(['REVIEW_ModelCompData_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL '.mat'],...
    'Up1','SFp1','dSFdtp1','RFLUXp1','HFLUXp1','timeP','timePflux');

end


figure('rend','painters','pos',[10 10 450 350])

subplot(2,1,1)

%load EASTERLYpertTime.mat
lim1 = -30; multiplierU = 4;
lim2 =  30;
%N = size(Up,1);
%N1 = N - (lim2-lim1)*multiplierU;
%field = field(N1:N,:);
%tt = lim1:1/multiplierU:lim2;
timeP = -50:0.5:30;

pos1 = 25;
pos2 = 56;
pos3 = 81.5;
lineWidth = 2;
helpLineWidth = 1;
fontSize = 12;




plot(timeP,Up1/max(abs(Up1)),'r','lineWidth',lineWidth); hold on;
plot(timeP,SFp1/max(abs(SFp1)),'b','lineWidth',lineWidth)
plot(timeP(2:end-1),dSFdtp1/max(abs(dSFdtp1)),'k','lineWidth',lineWidth)
plot(timePflux,RFLUXp1/max(abs(RFLUXp1)),'m','lineWidth',lineWidth)
%plot(timePflux,HFLUXp1/max(abs(HFLUXp1)),'g','lineWidth',lineWidth)
plot(timeP,0*SFp1/max(abs(SFp1)),'k','lineWidth',helpLineWidth)
plot([0 0],[-1.1 1.5],'k--','LineWidth',helpLineWidth)
%h = legend('\DeltaU','\DeltaSF','\partialSF/\partialt','l.h. flux','s.h. flux');
h = legend('\DeltaU','\DeltaSF','\partialSF/\partialt','l.h. flux');
set(h,'position',[0.80 .90 0.14 0.0],'fontsize', 8)
ylabel('', 'fontsize', fontSize)
xlabel('time lag (d)', 'fontsize', fontSize)
text(-27,1.12,'a)', 'fontsize',11)
%title('reanalysis climatology', 'fontsize', fontSize)
set(gca,'fontsize',fontSize)
xlim([-30 30])
ylim([-1.1 1.5])

subplot(2,1,2)
%subplot(4,1,4)
load fuchsModelFieldsTimeDepPert.mat;
plot(timep,Uptime,'r','lineWidth',lineWidth); hold on;
plot(timep,qptime,'b','lineWidth',lineWidth)
plot(timep,dqdtptime,'k','lineWidth',lineWidth)
plot(timep,-Uptime,'m','lineWidth',lineWidth); hold on;
plot(timep,Uptime*0,'k','lineWidth',helpLineWidth)
plot([0 0],[-1.1 1.5],'k--','LineWidth',helpLineWidth)
h = legend('\DeltaU','\Deltaq','\partialq/\partialt','l.h. flux');
set(h,'position',[0.80 .485 0.15 0.0],'fontsize', 8)
ylabel('', 'fontsize', fontSize)
xlabel('non-dimensional time lag', 'fontsize', fontSize)
text(-4.1,1.12,'b)', 'fontsize',11)
%title('Fuchs and Raymond (2017)', 'fontsize', fontSize)
set(gca,'fontsize',fontSize)
xlim([-4.5 4.5])
ylim([-1.1 1.5])

print(['REVIEW_PRODUCTION_figure5_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL '.eps'],'-depsc')
print(['REVIEW_PRODUCTION_figure5_' LON_EXCLUDE_LABEL '_' EXTRA_EXCLUDE_LABEL EXTRALABEL '.png'],'-dpng')


end



if 0

dt = 30;
t = [2254 3811 5675 4803 440 4425 5416 687 822 5821 3319 1810 3728 1251 5482 1890 5201 1832 5545 1787 1139 5792 1899 358];
t = index(:,2); 
OLRstrength = index(:,3);
for kk = 1:length(t)
  time1 = t(kk)-dt;
  time2 = t(kk)+dt;

  close all;
  figure('rend','painters','pos',[10 10 1400 900])

  colorbarFont = 12;
  plotFont = 12;

  subplot(4,2,3)
  field = U(Utime<time2&Utime>time1,:);
  VARlon = Ulon;
  VARtime = Utime;
  VARtime = VARtime(VARtime<time2&VARtime>time1)-t(kk);
  contourf(VARlon,VARtime,field,'LineColor','none'); hold on;
  colorbar('fontsize',colorbarFont)
  contour(VARlon,VARtime,field,[0 0],'linecolor','black','lineWidth',0.5);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfilt(OLRtime<time2&OLRtime>time1,:),[-10 -10],'linecolor','white','lineWidth',1);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfiltROSSBY(OLRtime<time2&OLRtime>time1,:),[-4 -4],'linecolor','red','lineWidth',1);
  set(gca, "fontsize", plotFont)
  title('U at 10 m (m/s)')
  ylabel('time (d)')
 

  subplot(4,2,5)
  field = SF(SFtime<time2&SFtime>time1,:);
  VARlon = SFlon;
  VARtime = SFtime;
  VARtime = VARtime(VARtime<time2&VARtime>time1)-t(kk);
  contourf(VARlon,VARtime,field,'LineColor','none'); hold on;
  colorbar('fontsize',colorbarFont)
  contour(VARlon,VARtime,field,[0.7 0.7],'linecolor','black','lineWidth',0.5);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),10+OLRfilt(OLRtime<time2&OLRtime>time1,:),[0 0],'linecolor','white','lineWidth',1);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),5.5+OLRfiltROSSBY(OLRtime<time2&OLRtime>time1,:),[0.5 0.5],'linecolor','red','lineWidth',1);
  set(gca, "fontsize", plotFont)
  title('saturation fraction (SF, [])')
  ylabel('time (d)')


  subplot(4,2,1)
  field = OLR(OLRtime<time2&OLRtime>time1,:);
  VARlon = OLRlon;
  VARtime = OLRtime;
  VARtime = VARtime(VARtime<time2&VARtime>time1)-t(kk);
  contourf(VARlon,VARtime,field,'LineColor','none'); hold on;
  colorbar('fontsize',colorbarFont)
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfilt(OLRtime<time2&OLRtime>time1,:),[-10 -10],'linecolor','white','lineWidth',1);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfiltROSSBY(OLRtime<time2&OLRtime>time1,:),[-4 -4],'linecolor','red','lineWidth',1);
  set(gca, "fontsize", plotFont)
  title(['OLR (W/m^2), day at 0: ' num2str(t(kk)) ', OLR_{min} = ' num2str(OLRstrength(kk),'%4.2f') ' W/m^2' ])
  ylabel('time (d)')

  subplot(4,2,7)
  field = dSFdt0(SFtime<time2&SFtime>time1,:);
  VARlon = SFlon;
  VARtime = SFtime;
  VARtime = VARtime(VARtime<time2&VARtime>time1)-t(kk);
  contourf(VARlon,VARtime,field,'LineColor','none'); hold on;
  colorbar('fontsize',colorbarFont)
  contour(VARlon,VARtime,field,[0 0],'linecolor','black','lineWidth',0.5);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),10+OLRfilt(OLRtime<time2&OLRtime>time1,:),[0 0],'linecolor','white','lineWidth',1);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),4+OLRfiltROSSBY(OLRtime<time2&OLRtime>time1,:),[0 0],'linecolor','red','lineWidth',1);
  set(gca, "fontsize", plotFont)
  title('dSF/dt (1/s)')
  ylabel('time (d)')
  xlabel('longitude (deg)')

  subplot(4,2,6)
  field = RFLUX(FLUXtime<time2&FLUXtime>time1,:);
  VARlon = FLUXlon;
  VARtime = FLUXtime;
  VARtime = VARtime(VARtime<time2&VARtime>time1)-t(kk);
  contourf(VARlon,VARtime,field,'LineColor','none'); hold on;
  colorbar('fontsize',colorbarFont)
  contour(VARlon,VARtime,field,[0 0],'linecolor','black','lineWidth',0.5);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfilt(OLRtime<time2&OLRtime>time1,:),[-10 -10],'linecolor','white','lineWidth',1);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfiltROSSBY(OLRtime<time2&OLRtime>time1,:),[-4 -4],'linecolor','red','lineWidth',1);
  set(gca, "fontsize", plotFont)
  title('OAFLUX latent heat flux (W/m^22)')
  ylabel('time (d)')

  subplot(4,2,8)
  field = HFLUX(FLUXtime<time2&FLUXtime>time1,:);
  VARlon = FLUXlon;
  VARtime = FLUXtime;
  VARtime = VARtime(VARtime<time2&VARtime>time1)-t(kk);
  contourf(VARlon,VARtime,field,'LineColor','none'); hold on;
  colorbar('fontsize',colorbarFont)
  contour(VARlon,VARtime,field,[0 0],'linecolor','black','lineWidth',0.5);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfilt(OLRtime<time2&OLRtime>time1,:),[-10 -10],'linecolor','white','lineWidth',1);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfiltROSSBY(OLRtime<time2&OLRtime>time1,:),[-4 -4],'linecolor','red','lineWidth',1);
  set(gca, "fontsize", plotFont)
  title('OAFLUX sentible heat flux (W/m^22)')
  ylabel('time (d)')
  xlabel('longitude (deg)')
  
  subplot(4,2,4)
  field = BUOYlh(BUOYtime<time2&BUOYtime>time1,:);
  VARlon = BUOYlon;
  VARtime = BUOYtime;
  VARtime = VARtime(VARtime<time2&VARtime>time1)-t(kk);
  contourf(VARlon,VARtime,field,'LineColor','none'); hold on;
  colorbar('fontsize',colorbarFont)
  contour(VARlon,VARtime,field,[0 0],'linecolor','black','lineWidth',0.5);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfilt(OLRtime<time2&OLRtime>time1,:),[-10 -10],'linecolor','white','lineWidth',1);
  contour(OLRlon,OLRtime(OLRtime<time2&OLRtime>time1)-t(kk),OLRfiltROSSBY(OLRtime<time2&OLRtime>time1,:),[-4 -4],'linecolor','red','lineWidth',1);
  set(gca, "fontsize", plotFont)
  title('BOUY sentible heat flux (W/m^22)')
  ylabel('time (d)')
  xlabel('longitude (deg)')

  
  fileName = [ 'SINGLE_' year1 '_' year2 '_' lat1 '_' lat2 '_' DATA '_VARIABLES_' num2str(t(kk)) '.png' ];
   print(fileName,'-dpng')


end

end

