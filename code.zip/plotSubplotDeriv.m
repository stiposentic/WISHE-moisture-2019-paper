function plotSubplotDeriv(VAR, VARlon, multiplier, cLimitL, cStep, cLimitU, YLABEL, XLABEL, TITLE,statTest)

dx = 1/multiplier;

field = mean(VAR,3);
mmm = max(max(field));
mmm = 10.5 + mmm;

lim1 = -30;
lim2 =  30;
N = size(field,1);
N1 = N - (lim2-lim1)*multiplier;
field = field(N1:N,:);
statTest = statTest(N1:N,:) + mmm;
tt = lim1:dx:lim2;

contourf(VARlon-180,tt,field,'LineColor','none'); hold on;
colorbar('fontsize',12)
caxis([min(field(:)), max(field(:))]);
contour(VARlon-180,tt,field,[0 0],'linecolor','black','lineWidth',0.5);
[c2,h2] = contourf(VARlon-180,lim1:dx:lim2,statTest,[mmm+0.5 mmm+0.5],'edgecolor','none'); % plots only one contour
cmap = colormap; cmap(end,:) = [0.75 0.75 0.75]; colormap(cmap)
plot([-180 180],[0 0],'w','linewidth',2); plot([0 0],[-50 30],'w','linewidth',2); plot([-180 180],[-36 36],'w','linewidth',2); hold off;
%set(gca, "fontsize", 12)
ylim([lim1 lim2])
ylabel(YLABEL,'fontsize',12)
xlabel(XLABEL,'fontsize',12)
xticks([-180 -120 -60 0 60 120 180])
xticklabels({'-180','-120','-60','0','60','120','180'})
title(TITLE,"interpreter","latex",'fontsize',12)


